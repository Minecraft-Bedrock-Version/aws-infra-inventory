from typing import Any, Dict, List

from normalizers.iam_user_normalizer import normalize_iam_users
from normalizers.iam_role_normalizer import normalize_iam_roles
from normalizers.network_normalizer import normalize_network
from normalizers.rds_normalizer import normalize_rds
from normalizers.sqs_normalizer import normalize_sqs
from normalizers.lambda_normalizer import normalize_lambda
from normalizers.ec2_normalizer import normalize_ec2

def run_normalizers(collected: Dict[str, Any]) -> Dict[str, Any]:
    account_id = collected["account_id"]
    region = collected["region"]
    collected_at = collected["collected_at"]

    # 1. 리소스를 종류별로 담을 딕셔너리 생성 (매우 중요!)
    normalized_map = {
        "schema_version": "1.0",
        "account_id": account_id,
        "region": region,
        "collected_at": collected_at,
        
        # 각 리소스 빌더(graph_builder)가 찾을 키 이름으로 정규화 데이터 배치
        "iam_user": {"nodes": normalize_iam_users(collected.get("iam_users", []), account_id), "account_id": account_id, "collected_at": collected_at},
        "iam_role": {"nodes": normalize_iam_roles(collected.get("iam_roles", []), account_id), "account_id": account_id, "collected_at": collected_at},
        "vpc": {"nodes": normalize_network(collected.get("network", []), account_id, region), "account_id": account_id, "collected_at": collected_at},
        "rds": {"nodes": normalize_rds(collected.get("rds", []), account_id, region), "account_id": account_id, "collected_at": collected_at},
        "sqs": {"nodes": normalize_sqs(collected.get("sqs", []), account_id, region), "account_id": account_id, "collected_at": collected_at},
        "lambda": {"nodes": normalize_lambda(collected.get("lambda", []), account_id, region), "account_id": account_id, "collected_at": collected_at},
        "ec2": {"nodes": normalize_ec2(collected.get("ec2", []), account_id, region), "account_id": account_id, "collected_at": collected_at}
    }

    return normalized_map