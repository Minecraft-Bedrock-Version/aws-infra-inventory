def extract_iam_role_for_vector(graph_data: dict) -> dict:

    vector_nodes = []

    for node in graph_data.get("nodes", []):

        if node.get("type") != "iam_role":
            continue

        properties = node.get("properties", {})

        assume_role_statements = []
        for stmt in properties.get("assume_role_policy", {}).get("Statement", []):
            assume_role_statements.append({
                "Effect": stmt.get("Effect"),
                "Action": stmt.get("Action")
            })

        inline_policies = []
        for policy in properties.get("inline_policies", []):
            statements = []
            for stmt in policy.get("Statement", []):
                statements.append({
                    "Action": stmt.get("Action", []),
                    "Effect": stmt.get("Effect")
                })
            inline_policies.append({
                "Statement": statements
            })

        iam_role_vector_node = {
            "id": node.get("id"),
            "type": "iam_role",
            "name": node.get("name"),
            "properties": {
                "assume_role_policy": {
                    "Statement": assume_role_statements
                },
                "inline_policies": inline_policies
            }
        }

        vector_nodes.append(iam_role_vector_node)

    return {
        "nodes": vector_nodes
    }