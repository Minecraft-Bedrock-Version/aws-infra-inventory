def extract_route_table_for_vector(graph_data: dict) -> dict:
    vector_nodes = []

    for node in graph_data.get("nodes", []):
        if node.get("type") != "route_table":
            continue

        props = node.get("properties", {})

        route_table_vector_node = {
            "id": node.get("id"),
            "type": "route_table",
            "name": node.get("name"),
            "properties": {
                "route_type": props.get("type") # 기존 type 필드명 충돌 방지 위해 route_type으로 명시
            }
        }
        vector_nodes.append(route_table_vector_node)

    return {"nodes": vector_nodes}