def extract_iam_user_for_vector(graph_data: dict) -> dict:
    vector_nodes = []

    for node in graph_data.get("nodes", []):
        if node.get("type") != "iam_user":
            continue

        props = node.get("properties", {})
        inline_policies = []

        for policy in props.get("inline_policies", []):
            statements = []
            for stmt in policy.get("Statement", []):
                statements.append({
                    "Effect": stmt.get("Effect"),
                    "Action": stmt.get("Action")
                })

            if statements:
                inline_policies.append({"Statement": statements})

        iam_user_vector_node = {
            "id": node.get("id"),
            "type": "iam_user",
            "name": node.get("name"),
            "properties": {
                "inline_policies": inline_policies
            }
        }
        vector_nodes.append(iam_user_vector_node)

    return {"nodes": vector_nodes}