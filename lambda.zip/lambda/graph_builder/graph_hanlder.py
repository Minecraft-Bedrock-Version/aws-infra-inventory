import re
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional

# 1. 개별 리소스 빌더 임포트
from graph_builder.iam_user_graph import transform_iam_users
from graph_builder.iam_role_graph import transform_iam_roles
from graph_builder.igw_graph import transform_igw_to_graph
from graph_builder.ec2_graph import transform_ec2_to_graph
from graph_builder.rds_graph import transform_rds_to_graph
from graph_builder.route_table_graph import transform_route_table_to_graph
from graph_builder.subnet_graph import transform_subnet_to_graph
from graph_builder.vpc_graph import transform_vpc_to_graph
from graph_builder.lambda_graph import transform_lambda_to_graph
from graph_builder.sqs_graph import transform_sqs_to_graph

class GraphAssembler:
    def __init__(self):
        self.transformer_map = {
            "iam_user": transform_iam_users,
            "iam_role": transform_iam_roles,
            "igw": transform_igw_to_graph,
            "ec2": transform_ec2_to_graph,
            "rds": transform_rds_to_graph,
            "route_table": transform_route_table_to_graph,
            "sqs": transform_sqs_to_graph,
            "lambda": transform_lambda_to_graph,
            "subnet": transform_subnet_to_graph,
            "vpc": transform_vpc_to_graph
        }

    def assemble(self, normalized_data_map: Dict[str, Any], cli_graph: Dict[str, Any] = None) -> Dict[str, Any]:
        master_nodes: Dict[str, Dict[str, Any]] = {}
        master_edges: Dict[str, Dict[str, Any]] = {}
        collected_at_list = []
        account_id = normalized_data_map.get("account_id", "unknown")

        # [Step 1] 일반 인프라 데이터 변환 및 병합
        for key, data in normalized_data_map.items():
            func = self.transformer_map.get(key) or self.transformer_map.get(key.rstrip('s'))
            if func and data and (data.get("nodes") or data.get("iam_users")):
                try:
                    res_graph = func(data)
                    self._merge_graph_to_master(master_nodes, master_edges, res_graph)
                    if res_graph.get("collected_at"):
                        collected_at_list.append(res_graph["collected_at"])
                except Exception as e:
                    print(f"Error transforming {key}: {e}")

        # [Step 2] CLI 데이터 변환 및 병합 (가상 노드 및 엣지 생성 포함)
        if cli_graph and cli_graph.get("nodes"):
            for node in cli_graph["nodes"]:
                # 1. CLI 노드(정규화 포맷)를 최종 노드 스키마로 변환하여 병합
                graph_node = self._convert_to_node_schema(node, account_id)
                n_id = graph_node["id"]
                master_nodes[n_id] = self._merge_nodes(master_nodes.get(n_id, {}), graph_node)

                # 2. 정책 기반 동적 엣지 및 가상 노드 생성
                new_edges = self._create_edges_and_placeholders(node, master_nodes, account_id)
                for e in new_edges:
                    master_edges[e["id"]] = e

            if cli_graph.get("collected_at"):
                collected_at_list.append(cli_graph["collected_at"])

        final_collected_at = max(collected_at_list) if collected_at_list else datetime.now(timezone.utc).isoformat()

        return {
            "schema_version": "1.0",
            "collected_at": final_collected_at,
            "account_id": account_id,
            "nodes": list(master_nodes.values()),
            "edges": list(master_edges.values())
        }

    def _convert_to_node_schema(self, node: Dict[str, Any], account_id: str) -> Dict[str, Any]:
        """정규화 포맷 노드를 최종 Node Schema로 변환"""
        node_id = node.get("node_id") or node.get("id")
        # node_id에서 region 추출 (형식: account:region:type:id)
        parts = node_id.split(":")
        region = parts[1] if len(parts) > 1 else "global"

        return {
            "id": node_id,
            "type": node.get("node_type") or node.get("type"),
            "name": node.get("name", "Unknown"),
            "arn": node.get("attributes", {}).get("arn", ""),
            "region": region,
            "properties": {
                **node.get("attributes", {}),
                "source": node.get("raw_refs", {}).get("source", [])
            }
        }

    def _create_edges_and_placeholders(self, cli_node: Dict[str, Any], master_nodes: Dict[str, Any], account_id: str) -> List[Dict[str, Any]]:
        """CLI 정책을 분석하여 엣지를 생성하고, 대상이 없으면 가상 노드를 마스터에 추가"""
        generated_edges = []
        src_id = cli_node.get("node_id")
        src_label = f"{cli_node.get('node_type')}:{cli_node.get('name')}"
        
        inline_policies = cli_node.get("attributes", {}).get("inline_policies", [])
        for policy in inline_policies:
            for stmt in policy.get("Statement", []):
                resource_arn = stmt.get("Resource")
                if not resource_arn or resource_arn == "*":
                    continue

                arns = resource_arn if isinstance(resource_arn, list) else [resource_arn]
                for arn in arns:
                    # 1. 기존 노드 중 ARN 매칭 확인
                    dst_node = next((n for n in master_nodes.values() if n.get("arn") == arn), None)
                    
                    # 2. 없으면 가상 노드(Placeholder) 생성
                    if not dst_node:
                        dst_node = self._create_placeholder_node(arn, account_id)
                        master_nodes[dst_node["id"]] = dst_node

                    # 3. 엣지 생성
                    relation = f"{stmt.get('Effect', 'Allow')}Access"
                    edge_id = f"edge:{src_id}:{relation}:{dst_node['id']}"
                    
                    generated_edges.append({
                        "id": edge_id,
                        "relation": relation,
                        "src": src_id,
                        "src_label": src_label,
                        "dst": dst_node["id"],
                        "dst_label": f"{dst_node['type']}:{dst_node['name']}",
                        "directed": True,
                        "conditions": stmt.get("Action", [])
                    })
        return generated_edges

    def _create_placeholder_node(self, arn: str, account_id: str) -> Dict[str, Any]:
        """ARN을 분석하여 존재하지 않는 리소스를 위한 가상 노드 생성"""
        # ARN 파싱 (arn:aws:service:region:account:resource)
        parts = arn.split(":")
        service = parts[2] if len(parts) > 2 else "unknown"
        region = parts[3] if len(parts) > 3 and parts[3] else "global"
        
        # 이름 추출 (마지막 섹션의 / 이후)
        res_name = parts[-1].split("/")[-1] if parts else "Unknown-Resource"
        
        # 우리 팀의 ID 규칙 적용
        virtual_id = f"{account_id}:{region}:{service}:{res_name}"
        
        return {
            "id": virtual_id,
            "type": service,
            "name": res_name,
            "arn": arn,
            "region": region,
            "properties": {
                "status": "placeholder",
                "exists_in_infra": False,
                "reason": "Created from CLI policy reference"
            }
        }

    # --- 기존 Merge 헬퍼 함수들 (유지) ---
    def _merge_graph_to_master(self, master_nodes, master_edges, sub_graph):
        for n in sub_graph.get("nodes", []):
            n_id = n.get("id")
            master_nodes[n_id] = self._merge_nodes(master_nodes.get(n_id, {}), n)
        for e in sub_graph.get("edges", []):
            e_id = e.get("id")
            master_edges[e_id] = self._merge_edges(master_edges.get(e_id, {}), e)

    def _merge_nodes(self, old: Dict[str, Any], new: Dict[str, Any]) -> Dict[str, Any]:
        merged = dict(old)
        for key in ["type", "name", "arn", "region"]:
            if not merged.get(key) and new.get(key):
                merged[key] = new[key]
        old_props = old.get("properties", {})
        new_props = new.get("properties", {})
        merged_props = {**old_props}
        for k, v in new_props.items():
            if k not in merged_props:
                merged_props[k] = v
            else:
                merged_props[k] = self._merge_property_value(merged_props[k], v)
        merged["properties"] = merged_props
        return merged

    def _merge_property_value(self, old_value: Any, new_value: Any) -> Any:
        if isinstance(old_value, dict) and isinstance(new_value, dict):
            merged = dict(old_value)
            for k, v in new_value.items():
                merged[k] = self._merge_property_value(merged.get(k), v) if k in merged else v
            return merged
        if isinstance(old_value, list) and isinstance(new_value, list):
            return list(set(map(str, old_value)) | set(map(str, new_value)))
        return new_value

    def _merge_edges(self, old: Dict[str, Any], new: Dict[str, Any]) -> Dict[str, Any]:
        merged = {**old, **new}
        return merged