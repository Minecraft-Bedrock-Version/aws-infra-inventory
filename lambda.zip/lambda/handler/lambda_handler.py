import sys
import os
import json 
from datetime import datetime

from collectors.collector_handler import handler as run_collectors
from collectors.cli_handler import run_cli_collector
from normalizers.normalizer_handler import run_normalizers
from graph_builder.graph_handler import GraphAssembler
from filters.filter_handler import run_filters 
from filters.filtering_handler import run_filtering 

def lambda_handler(event, context):
    cli_input = event.get("cli_input", "")
    account_id = event.get("account_id", "123456789012")

    # 데이터 수집 및 정규화
    cli_graph = run_cli_collector(cli_input, account_id)
    raw_data = run_collectors(event, context)
    normalized_data = run_normalizers(raw_data)

    # 그래프 조립 및 연결
    assembler = GraphAssembler()
    # assembler 내부에서 이미 id, properties 포맷으로 통일됨
    full_graph = assembler.assemble(normalized_data, cli_graph=cli_graph)
    full_graph["account_id"] = account_id # 메타데이터 주입
    
    # 필터링 및 필드 정제 
    if cli_graph.get("nodes"):
        # 보정 1: Assembler를 거친 후이므로 'id' 필드를 우선 참조
        start_node = cli_graph["nodes"][0]
        start_id = start_node.get("id") or start_node.get("node_id")
        
        # 연결 노드 추출
        sub_graph = run_filters(full_graph, start_id)
        # 필요 필드 필터링 (정성) -> 여기서 최종 스키마(1.0) 반환
        final_ai_graph = run_filtering(sub_graph, start_id)
    else:
        # CLI 입력이 없을 경우 전체 그래프 반환 (메타데이터 수동 추가)
        final_ai_graph = {
            "schema_version": "1.0",
            "collected_at": datetime.now().isoformat(),
            "account_id": account_id,
            "nodes": full_graph.get("nodes", []),
            "edges": full_graph.get("edges", [])
        }
   
    # 지정 경로에 파일 저장
    target_path = os.path.expanduser("~/ai_web-ui/backend/json/pandyo/search_pandyo.json")
    
    try:
        os.makedirs(os.path.dirname(target_path), exist_ok=True)
        with open(target_path, "w", encoding="utf-8") as f:
            json.dump(final_ai_graph, f, ensure_ascii=False, indent=2)
        save_status = f"Success: File overwritten at {target_path}"
    except Exception as e:
        save_status = f"Fail: {str(e)}"
        
    return {
        "statusCode": 200,
        "body": {
            "message": "Pipeline Completed",
            "save_status": save_status,
            "data": final_ai_graph
        }
    }