from collectors.CliToNode import cli_put_user_policy_to_iam_user_json
from graph_builder.iam_user_graph import transform_iam_users

def run_cli_collector(cli_input: str, account_id: str) -> dict:

    if not cli_input or cli_input.strip() == "":
        return {"nodes": [], "edges": []}
    
    try:
        # 1. 정규화된 CLI 데이터 생성
        cli_node_result = cli_put_user_policy_to_iam_user_json(
            cli_text=cli_input,
            account_id=account_id
        )
        
        # 2. transform_iam_users를 통해 graph 포맷으로 변환
        #    이렇게 하면 node_id가 id로 변환되고 node_type이 type으로 변환됨
        cli_graph = transform_iam_users(cli_node_result)
        
        return cli_graph
        
    except Exception as e:
        print(f"CLI 변환 중 오류 발생: {e}")
        import traceback
        traceback.print_exc()
        return {"nodes": [], "edges": []}