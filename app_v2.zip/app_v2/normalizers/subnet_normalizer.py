from datetime import datetime, timezone

def normalize_subnets(collected, account_id, region):
    nodes = []
    
    # route_table 정보는 이제 별도로 수집되므로 여기서는 사용하지 않음
    subnet_to_rt = {}

    for item in collected:
        sn = item.get("subnet") if isinstance(item, dict) else item
        if not sn:
            continue
            
        sn_id = sn.get("SubnetId")
        
        sn_name = None
        for tag in sn.get("Tags", []):
            if tag.get("Key") == "Name":
                sn_name = tag.get("Value")

        node = {
            "node_type": "subnet",
            "node_id": f"{account_id}:{region}:subnet:{sn_id}",
            "resource_id": sn_id,
            "name": sn_name,
            "attributes": {
                "vpc_id": sn.get("VpcId"),
                "cidr": sn.get("CidrBlock"),
                "az": sn.get("AvailabilityZone"),
                "visibility": "unknown", 
                "route_table_id": subnet_to_rt.get(sn_id)
            },
            "raw_refs": {
                "source": item.get("api_sources", ["ec2:DescribeSubnets"]) if isinstance(item, dict) else ["ec2:DescribeSubnets"],
                "collected_at": item.get("collected_at") if isinstance(item, dict) else None
            }
        }
        nodes.append(node)

    return nodes