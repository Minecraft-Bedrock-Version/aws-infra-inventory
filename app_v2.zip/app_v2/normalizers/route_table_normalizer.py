from datetime import datetime, timezone

def extract_name_from_tags(tags):
    if not tags: return None
    for tag in tags:
        if tag["Key"] == "Name":
            return tag["Value"]
    return None

def normalize_route_tables(collected, account_id, region):
    nodes = []
    items = collected

    for item in items:
        rt = item.get("route_table") if isinstance(item, dict) else item
        if not rt:
            continue
            
        rt_id = rt.get("RouteTableId")
        vpc_id = rt.get("VpcId")
        
        is_main = False
        associated_subnets = []
        for assoc in rt.get("Associations", []):
            if assoc.get("Main"):
                is_main = True
            if "SubnetId" in assoc:
                associated_subnets.append(assoc["SubnetId"])

        rt_type = "private"
        for route in rt.get("Routes", []):
            gateway_id = route.get("GatewayId", "")
            if gateway_id.startswith("igw-"):
                rt_type = "public"
                break

        node = {
            "node_type": "route_table",
            "node_id": f"{account_id}:{region}:rtb:{rt_id}",
            "resource_id": rt_id,
            "name": extract_name_from_tags(rt.get("Tags", [])),
            "attributes": {
                "vpc_id": vpc_id,
                "type": rt_type,
                "main": is_main
            },
            "relationships": {
                "associated_subnets": associated_subnets,
                "vpc_id": vpc_id
            },
            "raw_refs": {
                "source": ["ec2:DescribeRouteTables"],
                "collected_at": item.get("collected_at")
            }
        }
        nodes.append(node)

    return nodes