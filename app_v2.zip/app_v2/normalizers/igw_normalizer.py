from datetime import datetime, timezone

def extract_name_from_tags(tags):
    if not tags: return None
    for tag in tags:
        if tag["Key"] == "Name":
            return tag["Value"]
    return None

def normalize_igws(collected, account_id, region):
    nodes = []
    items = collected

    for item in items:
        igw = item.get("igw") if isinstance(item, dict) else item
        if not igw:
            continue
            
        igw_id = igw.get("InternetGatewayId")
        igw_name = extract_name_from_tags(igw.get("Tags", []))
        
        attachments = igw.get("Attachments", [])
        attached_vpc_id = attachments[0].get("VpcId") if attachments else None
        state = attachments[0].get("State") if attachments else "detached"

        node = {
            "node_type": "internet_gateway",
            "node_id": f"{account_id}:{region}:igw:{igw_id}",
            "resource_id": igw_id,
            "name": igw_name,
            "attributes": {
                "attached_vpc_id": attached_vpc_id,
                "state": state
            },
            "raw_refs": {
                "source": item.get("api_sources", ["ec2:DescribeInternetGateways"]),
                "collected_at": item.get("collected_at")
            }
        }
        nodes.append(node)

    return nodes