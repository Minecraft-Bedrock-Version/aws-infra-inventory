from datetime import datetime, timezone

def extract_name_from_tags(tags):
    if not tags: return None
    for tag in tags:
        if tag["Key"] == "Name":
            return tag["Value"]
    return None

def normalize_vpcs(collected, account_id, region):
    nodes = []

    for item in collected:
        vpc = item.get("vpc") if isinstance(item, dict) else item
        if not vpc:
            continue
            
        vpc_id = vpc.get("VpcId") 
        vpc_name = extract_name_from_tags(vpc.get("Tags", []))

        node = {
            "node_type": "vpc",
            "node_id": f"{account_id}:{region}:vpc:{vpc_id}",
            "resource_id": vpc_id,
            "name": vpc_name,
            "attributes": {
                "cidr": vpc.get("CidrBlock"), 
                "default": vpc.get("IsDefault", False),

                "internet_gateway_id": None 
            },
            "raw_refs": {
                "source": item.get("api_sources", ["ec2:DescribeVpcs"]),
                "collected_at": item.get("collected_at")
            }
        }
        nodes.append(node)

    return nodes