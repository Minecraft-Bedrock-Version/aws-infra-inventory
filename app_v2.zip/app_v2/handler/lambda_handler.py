import sys
import os
import json 
from datetime import datetime

from collectors.collector_handler import handler as run_collectors
from collectors.cli_handler import run_cli_collector
from normalizers.normalizer_handler import run_normalizers
from graph_builder.graph_handler import GraphAssembler
from filters.filter_handler import run_filters 
from filters.filterling_handler import run_filtering 

def lambda_handler(event, context):
    print("=== LAMBDA START ===")
    print("EVENT:", json.dumps(event, indent=2, ensure_ascii=False))
    cli_input = event.get("cli_input", "")
    account_id = event.get("account_id", "123456789012")
    region = event.get("region", "us-east-1")  # 기본값 추가

    # 데이터 수집 및 정규화 (region 필수!)
    cli_graph = run_cli_collector(cli_input, account_id)
    raw_data = run_collectors(event, context)
    print("RAW_DATA KEYS:", raw_data.keys())
    print("RAW_DATA TYPE:", type(raw_data))
    normalized_data = run_normalizers(raw_data)
    print("NORMALIZED KEYS:", normalized_data.keys())
    
    print("==== TYPE CHECK AFTER NORMALIZE ====")
    for k, v in normalized_data.items():
        print(f"{k}: {type(v)}")
        if isinstance(v, str):
            print(f"[WARN] {k} is STRING, value preview: {v[:200]}")
    
    resource_map = {}
    for k, v in normalized_data.items():
        target_v = v
        if isinstance(v, str):
            try:
                target_v = json.loads(v)
            except: continue
        
        if isinstance(target_v, dict) and "nodes" in target_v:
            resource_map[k] = target_v

    # 그래프 조립 및 연결
    assembler = GraphAssembler()
    print("ASSEMBLER INPUT KEYS:", resource_map.keys())
    for k, v in resource_map.items():
        if k != "account_id":
            nodes_count = len(v.get("nodes", [])) if isinstance(v, dict) else 0
            print(f"  {k}: {nodes_count} nodes")

    # assembler 내부에서 이미 id, properties 포맷으로 통일됨
    resource_map["account_id"] = account_id 
    full_graph = assembler.assemble(resource_map, cli_graph)
    try:
        debug_path = "full_graph_debug.json"
        with open(debug_path, "w", encoding="utf-8") as f:
            # full_graph가 dict이므로 바로 dump 가능
            json.dump(full_graph, f, ensure_ascii=False, indent=2, default=str)
        print(f"DEBUG: Full graph (Nodes: {len(full_graph.get('nodes', []))}, Edges: {len(full_graph.get('edges', []))}) saved to {debug_path}")
    except Exception as e:
        print(f"DEBUG_SAVE_ERROR: {str(e)}")
    
    # n['id'] 대신 n.get('id') 사용 및 None 필터링
    all_node_ids = [n.get('id') for n in full_graph.get('nodes', []) if n.get('id')]
    
    print(f"DEBUG: Full Graph Node IDs: {all_node_ids[:10]}... (Total: {len(all_node_ids)})")

    full_graph["account_id"] = account_id # 메타데이터 주입
    print("FULL_GRAPH:", {
        "nodes": len(full_graph.get("nodes", [])),
        "edges": len(full_graph.get("edges", []))
    })
    print("CLI_GRAPH:", cli_graph)
    
    # 필터링 전 그래프 저장 (디버그용)
    try:
        pre_filter_path = "graph_before_filtering.json"
        with open(pre_filter_path, "w", encoding="utf-8") as f:
            json.dump(full_graph, f, ensure_ascii=False, indent=2, default=str)
        print(f"DEBUG: Pre-filter graph saved to {pre_filter_path} - Nodes: {len(full_graph.get('nodes', []))}, EC2 count: {len([n for n in full_graph.get('nodes', []) if n.get('type') == 'ec2_instance'])}")
    except Exception as e:
        print(f"DEBUG_SAVE_ERROR (pre-filter): {str(e)}")
    
    # 필터링 및 필드 정제 
    if cli_graph.get("nodes"):
        start_id = cli_graph["nodes"][0].get("id")
        print(f"DEBUG: Searching for START_ID: {start_id}")
        
        # 필터링
        sub_graph = run_filters(full_graph, start_id)
        print(f"DEBUG: Sub-graph result - Nodes: {len(sub_graph.get('nodes', []))}")

        # 2. 최종 정제 (데이터가 있을 때만 실행)
        if sub_graph.get("nodes"):
            final_ai_graph = run_filtering(sub_graph, start_id)
            print(f"CHECK: final_ai_graph nodes count = {len(final_ai_graph.get('nodes', []))}")
            try:
                print(f"CHECK: final_ai_graph content = {json.dumps(final_ai_graph, default=str)[:500]}")
            except:
                print("CHECK: final_ai_graph content = <복잡한 구조>")
        else:
            print("WARN: No nodes found in sub_graph. Returning full_graph instead.")
            final_ai_graph = full_graph
    else:
        final_ai_graph = {
            "schema_version": "1.0",
            "collected_at": datetime.now().isoformat(),
            "account_id": account_id,
            "nodes": [],
            "edges": []
        }
   
    # 지정 경로에 파일 저장
    # target_path = os.path.expanduser("~/ai_web-ui/backend/json/pandyo/search_pandyo.json")
    
    # try:
    #     os.makedirs(os.path.dirname(target_path), exist_ok=True)
    #     with open(target_path, "w", encoding="utf-8") as f:
    #         json.dump(final_ai_graph, f, ensure_ascii=False, indent=2)
    #     save_status = f"Success: File overwritten at {target_path}"
    # except Exception as e:
    #     save_status = f"Fail: {str(e)}"
    
    # local_test_result.json에 저장 (최종 결과)
    try:
        with open("local_test_result.json", "w", encoding="utf-8") as f:
            json.dump(final_ai_graph, f, ensure_ascii=False, indent=2, default=str)
        print(f"DEBUG: Final result saved to local_test_result.json")
    except Exception as e:
        print(f"DEBUG_SAVE_ERROR (final): {str(e)}")
        
    return {
        "statusCode": 200,
        "body": json.dumps(final_ai_graph, default=str)
    }
    
if __name__ == "__main__":
    import boto3
    
    # AWS 크레덴셜 확인
    session = boto3.Session()
    creds = session.get_credentials()
    if creds:
        print(f"✅ AWS 크레덴셜 설정됨 (Access Key: {creds.access_key[:10]}...)")
    else:
        print("❌ AWS 크레덴셜 없음! ~/.aws/credentials 확인 필요")
    
    # 실제 AWS 계정 정보 조회
    sts_client = boto3.client('sts')
    try:
        identity = sts_client.get_caller_identity()
        account_id = identity['Account']
        user_arn = identity['Arn']
        print(f"✅ 현재 AWS 계정: {account_id}")
        print(f"✅ 사용자/역할: {user_arn}")
    except Exception as e:
        print(f"❌ AWS 연결 실패: {e}")
        print("   프로필 설정: export AWS_PROFILE=<your-profile>")
        account_id = "288528695623"
    
    # 1. 테스트용 event 객체 생성 (실제 AWS 환경에서)
    test_event = {
        "cli_input": "aws iam put-user-policy --user-name scp-test --policy-name cg-sqs-scenario-assumed-role --policy-document '{\"Version\": \"2012-10-17\",\"Statement\": [{\"Effect\": \"Allow\",\"Action\": [\"iam:Get*\",\"iam:List*\"],\"Resource\": \"*\"},{\"Effect\": \"Allow\",\"Resource\": \"*\",\"Action\": \"sts:AssumeRole\"}]}'",
        "account_id": account_id,
        "region": "us-east-1"
    }

    class MockContext:
        def __init__(self):
            self.function_name = "local_test_lambda"
            self.memory_limit_in_mb = 128
            self.invoked_function_arn = "arn:aws:lambda:local:000000000000:function:test"
            self.aws_request_id = "local-req-id"

    # 2. 실제 AWS 서비스 호출 시작
    print("\n--- 실제 AWS 서비스 호출 시작 ---")
    print("수집 범위:")
    print("  - IAM Roles, Users")
    print("  - EC2 Instances")
    print("  - RDS Databases")
    print("  - SQS Queues")
    print("  - VPCs, Subnets, IGWs")
    print("  - Lambda Functions")
    
    # 3. 핸들러 실행 (실제 AWS 데이터 수집)
    result = lambda_handler(test_event, MockContext())
    
    # 4. 결과 출력
    final_output = json.loads(result["body"])
    print("\n--- 실행 완료 ---")
    print(f"✅ 노드 발견: {len(final_output.get('nodes', []))}")
    print(f"✅ 엣지 발견: {len(final_output.get('edges', []))}")
    
    # 노드 타입별 분류
    node_types = {}
    for node in final_output.get('nodes', []):
        ntype = node.get('type', 'unknown')
        node_types[ntype] = node_types.get(ntype, 0) + 1
    
    print("\n📊 노드 타입 분포:")
    for ntype, count in sorted(node_types.items()):
        print(f"  - {ntype}: {count}")
    
    # 결과를 파일로 저장
    with open("local_test_result.json", "w", encoding="utf-8") as f:
        json.dump(final_output, f, indent=2, ensure_ascii=False)
    print(f"\n💾 결과 저장: local_test_result.json")