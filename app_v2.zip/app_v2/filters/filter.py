from typing import Dict, List, Set, Any

def extract_connected_subgraph(
    graph_nodes: List[Dict[str, Any]], 
    graph_edges: List[Dict[str, Any]],
    start_node_id: str,
) -> Dict[str, List]:

    # node_id와 id를 모두 확인하여 노드 인덱싱
    node_index = {}
    for n in graph_nodes:
        node_id = n.get("node_id") or n.get("id")
        if node_id:
            node_index[node_id] = n
    
    print(f"[DEBUG] node_index keys: {list(node_index.keys())}")
    print(f"[DEBUG] Looking for start_node_id: {start_node_id}")
    
    adj = {n_id: [] for n_id in node_index}
    edge_map = {}
    
    if start_node_id not in node_index:
        print(f"[DEBUG] start_node_id not found in node_index!")
        return {"nodes": [], "edges": []}

    for edge in graph_edges:
        e_id = edge.get("id")
        src = edge.get("src")
        dst = edge.get("dst")
        
        if src in adj and dst in adj:
            adj[src].append((dst, e_id))
            adj[dst].append((src, e_id))
            edge_map[e_id] = edge

    visited_nodes: Set[str] = set()
    visited_edges: Set[str] = set()
    queue: List[str] = [start_node_id]

    while queue:
        current_node_id = queue.pop(0)

        if current_node_id in visited_nodes:
            continue

        visited_nodes.add(current_node_id)

        for neighbor_id, e_id in adj.get(current_node_id, []):
            visited_edges.add(e_id)
            if neighbor_id not in visited_nodes:
                queue.append(neighbor_id)

    print(f"[DEBUG] Found {len(visited_nodes)} connected nodes and {len(visited_edges)} edges")
    
    # 인프라 노드들도 항상 포함 (RDS, Lambda, SQS, EC2 등)
    infrastructure_types = {
        'ec2_instance', 'ec2',
        'rds_instance', 'rds',
        'lambda_function', 'lambda_event_source_mapping',
        'sqs',
        'subnet', 'vpc', 'igw', 'route_table', 'internet_gateway',
        'key_pair', 'rds_subnet_group'
    }
    
    for n_id, node in node_index.items():
        node_type = node.get('type', '')
        if node_type in infrastructure_types and n_id not in visited_nodes:
            visited_nodes.add(n_id)
            print(f"[DEBUG] Adding infrastructure node: {node.get('name')} (type: {node_type})")
    
    return {
        "nodes": [node_index[nid] for nid in visited_nodes],
        "edges": [edge_map[eid] for eid in visited_edges],
    }