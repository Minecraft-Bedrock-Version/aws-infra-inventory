from filters.filter import extract_connected_subgraph

def run_filters(full_graph: dict, start_node_id: str) -> dict:

    nodes = full_graph.get("nodes", [])
    edges = full_graph.get("edges", [])

    if not start_node_id:
        return {"nodes": [], "edges": []}
    
    result = extract_connected_subgraph(
        graph_nodes=nodes,
        graph_edges=edges,
        start_node_id=start_node_id
    )
    
    # 인프라 노드들도 항상 포함
    infrastructure_types = {
        'ec2_instance', 'ec2',
        'rds_instance', 'rds',
        'lambda_function', 'lambda_event_source_mapping',
        'sqs',
        'subnet', 'vpc', 'igw', 'route_table', 'internet_gateway',
        'key_pair', 'rds_subnet_group'
    }
    
    result_node_ids = {n.get('id') or n.get('node_id') for n in result.get('nodes', [])}
    
    # 인프라 노드를 전체 그래프에서 찾아 추가
    for node in nodes:
        node_id = node.get('id') or node.get('node_id')
        node_type = node.get('type', '')
        
        if node_type in infrastructure_types and node_id not in result_node_ids:
            result['nodes'].append(node)
            print(f"[DEBUG] Adding infrastructure node to subgraph: {node.get('name')} (type: {node_type})")
    
    return result