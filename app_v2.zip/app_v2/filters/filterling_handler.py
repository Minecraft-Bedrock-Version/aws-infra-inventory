from datetime import datetime
from filters.filter import extract_connected_subgraph
from filters.ec2 import extract_ec2_for_vector
from filters.rds import extract_rds_for_vector
from filters.edge import extract_edges_for_vector
from filters.iam_role import extract_iam_role_for_vector 
from filters.iam_user import extract_iam_user_for_vector
from filters.igw import extract_igw_for_vector
from filters.lambda_filtering import extract_lambda_for_vector
from filters.route_table import extract_route_table_for_vector
from filters.sqs import extract_sqs_for_vector
from filters.subnet import extract_subnet_for_vector
from filters.vpc import extract_vpc_for_vector

def run_filtering(full_graph: dict, start_node_id: str) -> dict:

    print(f"[DEBUG] run_filtering called with start_node_id: {start_node_id}")
    print(f"[DEBUG] Full graph has {len(full_graph.get('nodes', []))} nodes and {len(full_graph.get('edges', []))} edges")
    
    subgraph = extract_connected_subgraph(
        graph_nodes=full_graph.get("nodes", []),
        graph_edges=full_graph.get("edges", []),
        start_node_id=start_node_id
    )
    
    print(f"[DEBUG] Subgraph extracted: {len(subgraph.get('nodes', []))} nodes, {len(subgraph.get('edges', []))} edges")
    
    # ==================== IAM List/Get 권한 필터링 ====================
    # iam:List*, iam:Get* 권한으로만 접근 가능한 노드/엣지 제외
    nodes_set = {n.get('id'): n for n in subgraph.get('nodes', [])}
    edges_list = subgraph.get('edges', [])
    
    # 제거할 노드 ID와 엣지 ID 추적
    nodes_to_remove = set()
    edges_to_remove = set()
    
    # Step 1: iam:List*, iam:Get* 권한으로만 도달 가능한 엣지 찾기
    for edge in edges_list:
        conditions = edge.get('conditions', [])
        
        # 조건이 iam:List* 또는 iam:Get*만 있는지 확인
        is_iam_readonly = all(
            isinstance(c, str) and (c.startswith('iam:list') or c.startswith('iam:get') or 
                                   c.startswith('iam:List') or c.startswith('iam:Get'))
            for c in conditions
            if isinstance(c, str)
        )
        
        if is_iam_readonly and conditions:  # 조건이 있어야 함
            edges_to_remove.add(edge.get('id'))
            print(f"[DEBUG] Filtering out IAM readonly edge: {edge.get('src_label')} → {edge.get('dst_label')}")
    
    # Step 2: 제거된 엣지로만 도달 가능한 노드 찾기
    remaining_edges = [e for e in edges_list if e.get('id') not in edges_to_remove]
    
    # 시작 노드로부터 도달 가능한 노드 찾기 (remaining_edges 사용)
    reachable = {start_node_id}
    changed = True
    while changed:
        changed = False
        for edge in remaining_edges:
            if edge.get('src') in reachable and edge.get('dst') not in reachable:
                reachable.add(edge.get('dst'))
                changed = True
    
    # 도달 불가능한 노드 제거 (단, 인프라 노드는 제외)
    # 인프라 노드: ec2, rds, lambda, sqs, subnet, vpc, igw 등
    infrastructure_types = {
        'ec2_instance', 'ec2', 
        'rds_instance', 'rds',
        'lambda_function', 'lambda_event_source_mapping',
        'sqs', 
        'subnet', 'vpc', 'igw', 'route_table', 'internet_gateway',
        'key_pair', 'rds_subnet_group'
    }
    
    for node_id in list(nodes_set.keys()):
        node = nodes_set[node_id]
        node_type = node.get('type', '')
        
        # 인프라 노드는 무조건 보존
        if node_type in infrastructure_types:
            continue
            
        # IAM 리소스는 도달 불가능하면 제거
        if node_id not in reachable:
            nodes_to_remove.add(node_id)
            print(f"[DEBUG] Filtering out unreachable node after IAM readonly removal: {nodes_set[node_id].get('name')}")
    
    # Step 3: 한쪽 끝이 제거된 노드인 엣지도 제거
    final_edges = [
        e for e in remaining_edges
        if e.get('src') not in nodes_to_remove and e.get('dst') not in nodes_to_remove
    ]
    
    final_nodes = [n for node_id, n in nodes_set.items() if node_id not in nodes_to_remove]
    
    print(f"[DEBUG] After IAM readonly filtering: {len(final_nodes)} nodes, {len(final_edges)} edges")
    # ================================================================
    
    refine_map = {
        "ec2": extract_ec2_for_vector,
        "rds_instance": extract_rds_for_vector,
        "iam_role": extract_iam_role_for_vector,
        "iam_user": extract_iam_user_for_vector,
        "internet_gateway": extract_igw_for_vector,
        "lambda_function": extract_lambda_for_vector,
        "route_table": extract_route_table_for_vector,
        "sqs": extract_sqs_for_vector,
        "subnet": extract_subnet_for_vector,
        "vpc": extract_vpc_for_vector
    }

    refined_nodes = []
    
    for node in final_nodes:
        node_type = node.get("type")
        if node_type in refine_map:
            refined = refine_map[node_type]({"nodes": [node]})
            refined_nodes.extend(refined.get("nodes", []))
        else:
            refined_nodes.append(node)

    # 엣지는 필터링된 것을 그대로 반환 (refine 불필요)
    
    print(f"[DEBUG] Final output: {len(refined_nodes)} nodes, {len(final_edges)} edges")

    return {
        "schema_version": "1.0",
        "collected_at": datetime.now().isoformat(),
        "account_id": full_graph.get("account_id", "unknown"),
        "nodes": refined_nodes,
        "edges": final_edges
    }