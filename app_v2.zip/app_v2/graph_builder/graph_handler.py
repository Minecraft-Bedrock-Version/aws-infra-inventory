import re
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
import json

# 1. 개별 리소스 빌더 임포트
from graph_builder.iam_user_graph import transform_iam_users
from graph_builder.iam_role_graph import transform_iam_roles
from graph_builder.igw_graph import transform_igw_to_graph
from graph_builder.ec2_graph import transform_ec2_to_graph
from graph_builder.rds_graph import transform_rds_to_graph
from graph_builder.route_table_graph import transform_route_table_to_graph
from graph_builder.subnet_graph import transform_subnet_to_graph
from graph_builder.vpc_graph import transform_vpc_to_graph
from graph_builder.lambda_graph import transform_lambda_to_graph
from graph_builder.sqs_graph import transform_sqs_to_graph

def safe_node(n):
    if not n: return None
    if isinstance(n, dict): return n
    try:
        curr = n
        for _ in range(3):
            if isinstance(curr, (str, bytes)):
                curr = json.loads(curr)
            else:
                break
        return curr if isinstance(curr, dict) else None
    except:
        return None

class GraphAssembler:
    def __init__(self):
        self.transformer_map = {
            "iam_user": transform_iam_users,
            "iam_role": transform_iam_roles,
            "igw": transform_igw_to_graph,
            "ec2": transform_ec2_to_graph,
            "rds": transform_rds_to_graph,
            "route_table": transform_route_table_to_graph,
            "sqs": transform_sqs_to_graph,
            "lambda": transform_lambda_to_graph,
            "subnet": transform_subnet_to_graph,
            "vpc": transform_vpc_to_graph
        }

    def assemble(self, normalized_data_map: Dict[str, Any], cli_graph: Dict[str, Any] = None) -> Dict[str, Any]:
        master_nodes = {}
        master_edges = {}
        account_id = str(normalized_data_map.get("account_id", "288528695623"))

        # 1. 인프라 데이터 수집 및 ID 강제 변환
        for key, data in normalized_data_map.items():
            if key in ["account_id", "region", "collected_at", "schema_version"]:
                continue
            
            current_data = safe_node(data)
            if not isinstance(current_data, dict) or "nodes" not in current_data:
                print(f"[DEBUG] Skipped {key}: not a dict with nodes")
                continue

            # 트랜스포머 실행
            func = self.transformer_map.get(key) or self.transformer_map.get(key.rstrip('s'))
            if func:
                try:
                    print(f"[DEBUG] Processing {key}: {len(current_data.get('nodes', []))} nodes")
                    # transformer가 기대하는 account_id, collected_at 추가
                    if "account_id" not in current_data:
                        current_data["account_id"] = account_id
                    if "collected_at" not in current_data:
                        current_data["collected_at"] = datetime.now().isoformat()
                    
                    res_graph = func(current_data)
                    print(f"[DEBUG] {key} transformer result: {len(res_graph.get('nodes', []))} nodes, {len(res_graph.get('edges', []))} edges")
                    
                    for n in res_graph.get("nodes", []):
                        # attributes가 없으면 properties 기반으로 생성
                        if "attributes" not in n and "properties" in n:
                            n["attributes"] = dict(n.get("properties", {}))
                        
                        n_id = n.get("id")
                        if n_id:
                            master_nodes[n_id] = n
                    
                    for e in res_graph.get("edges", []):
                        if e.get("id"): master_edges[e["id"]] = e
                except Exception as e:
                    print(f"[ERROR] Exception in transformer for {key}: {e}")
                    import traceback
                    traceback.print_exc()
                    continue

        # 2. CLI 그래프 병합 (ID 형식 표준화: account:global:iam_user:name)
        if cli_graph and cli_graph.get("nodes"):
            for cli_node in cli_graph["nodes"]:
                # CLI 노드의 ID는 이미 graph 포맷이므로 id를 사용
                c_id = cli_node.get("id")
                cli_name = cli_node.get("name")
                
                print(f"[DEBUG] Processing CLI node: {c_id}, name: {cli_name}")
                
                # 1단계: id로 직접 매칭 시도
                matched_node_id = None
                if c_id in master_nodes:
                    matched_node_id = c_id
                    print(f"[DEBUG] Found matching node by id: {c_id}")
                else:
                    # 2단계: name으로 매칭 시도 (중복된 name이 있는지 확인)
                    for existing_id, existing_node in master_nodes.items():
                        existing_name = existing_node.get("name")
                        if existing_name and existing_name == cli_name:
                            matched_node_id = existing_id
                            print(f"[DEBUG] Found matching node by name '{cli_name}': {existing_id}")
                            break
                
                # 매칭된 노드가 있으면 병합
                if matched_node_id:
                    print(f"[DEBUG] Merging CLI node with existing node: {matched_node_id}")
                    # 인프라 노드에 CLI에서 온 정책 정보를 병합
                    existing_attrs = master_nodes[matched_node_id].get("attributes", {})
                    cli_attrs = cli_node.get("attributes", {})
                    
                    # inline_policies 병합
                    existing_policies = existing_attrs.get("inline_policies", [])
                    cli_policies = cli_attrs.get("inline_policies", [])
                    existing_attrs["inline_policies"] = existing_policies + cli_policies
                    
                    # 기타 속성 업데이트
                    for key, value in cli_attrs.items():
                        if key != "inline_policies":
                            existing_attrs[key] = value
                    
                    master_nodes[matched_node_id]["attributes"] = existing_attrs
                    print(f"[DEBUG] Successfully merged CLI node into: {matched_node_id}")
                else:
                    print(f"[DEBUG] No matching node found, creating new: {c_id}")
                    # 만약 인프라에 없었다면 새로 추가 (안전장치)
                    master_nodes[c_id] = self._convert_to_node_schema(cli_node, account_id)
                    master_nodes[c_id]["id"] = c_id  # ID 명시적으로 설정
                    matched_node_id = c_id

                # 엣지 생성 (관계 확장) - 모든 노드가 이제 master_nodes에 있음
                # 병합된 노드(matched_node_id)를 기준으로 엣지 생성
                cli_node_with_updated_id = dict(cli_node)
                cli_node_with_updated_id["node_id"] = matched_node_id  # 엣지 생성 시 정확한 ID 사용
                
                new_edges = self._create_edges_and_placeholders(cli_node_with_updated_id, master_nodes, account_id)
                print(f"[DEBUG] Created {len(new_edges)} edges for CLI node {cli_name}")
                for e in new_edges:
                    master_edges[e["id"]] = e
        
        # 3단계: IAM Role/User의 정책 기반 엣지도 생성 (간접 연결 지원)
        print(f"[DEBUG] Processing policy-based edges for all IAM resources")
        
        # Service와 실제 노드 ID의 매핑을 위한 역맵 구축
        service_nodes = {}  # service_type -> [node_ids]
        for n_id, n in master_nodes.items():
            n_type = n.get("type", "").lower()
            if n_type not in service_nodes:
                service_nodes[n_type] = []
            service_nodes[n_type].append(n_id)
        
        # 노드들을 리스트로 변환하여 순회 (dictionary 크기 변경 문제 해결)
        nodes_to_process = list(master_nodes.items())
        placeholders_to_add = {}  # placeholder_id -> node
        new_edges = {}  # edge_id -> edge
        
        for node_id, node in nodes_to_process:
            node_type = node.get("type", "").lower()
            
            # IAM User 또는 Role만 처리
            if node_type not in ["iam_user", "iam_role"]:
                continue
            
            attrs = node.get("attributes", {})
            inline_policies = attrs.get("inline_policies", [])
            attached_policies = attrs.get("attached_policies", [])
            
            # 이 노드의 모든 정책을 처리 (inline + attached)
            all_policies = inline_policies + attached_policies
            
            # 이 노드의 정책을 기반으로 엣지 생성
            for policy in all_policies:
                for stmt in policy.get("Statement", []):
                    resource_arn = stmt.get("Resource")
                    actions = stmt.get("Action", [])
                    if isinstance(actions, str): 
                        actions = [actions]
                    
                    if not resource_arn: 
                        continue
                    
                    # Resource를 정규화 (배열 또는 문자열을 배열로)
                    if isinstance(resource_arn, str):
                        resources = [resource_arn]
                    elif isinstance(resource_arn, list):
                        resources = resource_arn
                    else:
                        continue
                    
                    # "*"가 포함되어 있는지 확인
                    has_wildcard = "*" in resources
                    
                    # Resource가 "*"인 경우 처리
                    if has_wildcard:
                        # 먼저 기존 노드들과 매칭
                        for target_id, target_node in nodes_to_process:
                            if target_id == node_id: 
                                continue
                            
                            target_type = target_node.get("type", "").lower()
                            service_map = {
                                "rds_instance": "rds",
                                "sqs": "sqs",
                                "lambda_function": "lambda",
                                "ec2_instance": "ec2",
                                "iam_role": "iam",
                                "iam_user": "iam"
                            }
                            service_prefix = service_map.get(target_type)
                            
                            # sts:AssumeRole 특수 처리
                            if any(act in actions for act in ["sts:AssumeRole", "sts:*", "*"]):
                                if target_type == "iam_role":
                                    edge_id = f"edge:{node_id}:AssumeRole:{target_id}"
                                    if edge_id not in master_edges:
                                        node_name = node.get('name', 'unknown')
                                        target_name = target_node.get('name', 'unknown')
                                        print(f"[DEBUG] Creating AssumeRole edge: {node_name} → {target_name}")
                                        master_edges[edge_id] = {
                                            "id": edge_id,
                                            "relation": "AssumeRole",
                                            "src": node_id,
                                            "src_label": f"{node_type}:{node_name}",
                                            "dst": target_id,
                                            "dst_label": f"{target_type}:{target_name}",
                                            "directed": True,
                                            "conditions": ["sts:AssumeRole"]
                                        }
                            
                            # 일반 서비스 접근 권한
                            if service_prefix and target_type not in ["iam_role", "iam_user"]:
                                is_match = any(
                                    act == "*" or 
                                    act.startswith(f"{service_prefix}:") or 
                                    act == f"{service_prefix}:*"
                                    for act in actions
                                )
                                
                                if is_match:
                                    edge_id = f"edge:{node_id}:ActionMatch:{target_id}"
                                    if edge_id not in master_edges:
                                        node_name = node.get('name', 'unknown')
                                        target_name = target_node.get('name', 'unknown')
                                        print(f"[DEBUG] Creating ActionMatch edge: {node_name} → {target_name}")
                                        master_edges[edge_id] = {
                                            "id": edge_id,
                                            "relation": "AllowAccess",
                                            "src": node_id,
                                            "src_label": f"{node_type}:{node_name}",
                                            "dst": target_id,
                                            "dst_label": f"{target_type}:{target_name}",
                                            "directed": True,
                                            "conditions": actions
                                        }
                        
                        # 이제 action 기반으로 서비스를 추출하고 placeholder 노드 생성
                        # 허용할 서비스만 필터링
                        ALLOWED_SERVICES = {"ec2", "iam", "rds", "sqs", "vpc", "subnet", "igw"}
                        
                        services_in_actions = set()
                        for action in actions:
                            if isinstance(action, str) and ":" in action:
                                service_prefix = action.split(":")[0].lower()
                                # 허용된 서비스만 추가
                                if service_prefix in ALLOWED_SERVICES:
                                    services_in_actions.add(service_prefix)
                        
                        # 각 서비스에 대해 placeholder 노드와 엣지 생성
                        for service_name in services_in_actions:
                            # 해당 서비스의 노드가 이미 있는지 확인
                            existing_service_nodes = [
                                n_id for n_id, n in nodes_to_process
                                if service_name in n.get('type', '').lower() or 
                                service_name in (n.get('name', '') or '').lower()
                            ]
                            
                            if existing_service_nodes:
                                # 기존 노드와 연결 (위에서 이미 처리됨)
                                continue
                            else:
                                # Placeholder 생성
                                placeholder_id = f"{account_id}:global:{service_name}:placeholder"
                                
                                if placeholder_id not in master_nodes and placeholder_id not in placeholders_to_add:
                                    placeholders_to_add[placeholder_id] = {
                                        "id": placeholder_id,
                                        "type": service_name,
                                        "name": f"{service_name}-placeholder",
                                        "arn": f"arn:aws:{service_name}:*:{account_id}:*",
                                        "region": "global",
                                        "placeholder": True,
                                        "properties": {},
                                        "attributes": {}
                                    }
                                    print(f"[DEBUG] Created placeholder node: {service_name}")
                                
                                # Placeholder와 엣지 생성
                                edge_id = f"edge:{node_id}:AllowAccess:{placeholder_id}"
                                if edge_id not in master_edges and edge_id not in new_edges:
                                    node_name = node.get('name', 'unknown')
                                    print(f"[DEBUG] Creating AllowAccess edge to {service_name}: {node_name} → {service_name}-placeholder")
                                    new_edges[edge_id] = {
                                        "id": edge_id,
                                        "relation": "AllowAccess",
                                        "src": node_id,
                                        "src_label": f"{node_type}:{node_name}",
                                        "dst": placeholder_id,
                                        "dst_label": f"{service_name}:placeholder",
                                        "directed": True,
                                        "conditions": [a for a in actions if a.startswith(f"{service_name}:") or a == "*"]
                                    }
        
        # Placeholder 노드와 엣지를 master에 추가
        master_nodes.update(placeholders_to_add)
        master_edges.update(new_edges)
        
        return {
            "nodes": list(master_nodes.values()),
            "edges": list(master_edges.values()),
            "account_id": account_id,
            "collected_at": datetime.now().isoformat()
        }
        
    def _convert_to_node_schema(self, node: Dict[str, Any], account_id: str) -> Dict[str, Any]:
        """정규화 포맷 노드를 최종 Node Schema로 변환"""
        node_id = node.get("node_id") or node.get("id")
        # node_id에서 region 추출 (형식: account:region:type:id)
        parts = node_id.split(":")
        region = parts[1] if len(parts) > 1 else "global"
        node_type = node.get("node_type") or node.get("type", "unknown")

        return {
            "id": node_id,
            "node_id": node_id,  # 이중 저장으로 호환성 보장
            "type": node_type,
            "name": node.get("name", "Unknown"),
            "arn": node.get("attributes", {}).get("arn", ""),
            "region": region,
            "properties": {
                **node.get("attributes", {}),
                "source": node.get("raw_refs", {}).get("source", [])
            },
            "attributes": node.get("attributes", {})
        }

    def _create_edges_and_placeholders(self, cli_node: Dict[str, Any], master_nodes: Dict[str, Any], account_id: str) -> List[Dict[str, Any]]:
        generated_edges = []
        src_id = cli_node.get("node_id")
        src_type = cli_node.get("node_type", "unknown")
        src_name = cli_node.get("name", "unknown")
        src_label = f"{src_type}:{src_name}"
        
        print(f"[DEBUG] _create_edges_and_placeholders - src_id: {src_id}, src_label: {src_label}, total_nodes: {len(master_nodes)}")
        
        # 리소스 타입별 매칭 가능한 서비스 접두사 정의
        service_map = {
            "rds_instance": "rds",
            "rds": "rds",
            "sqs": "sqs",
            "lambda_function": "lambda",
            "lambda": "lambda",
            "ec2_instance": "ec2",
            "ec2": "ec2",
            "iam_role": "iam",
            "iam_user": "iam"
        }

        inline_policies = cli_node.get("attributes", {}).get("inline_policies", [])
        for policy in inline_policies:
            for stmt in policy.get("Statement", []):
                resource_arn = stmt.get("Resource")
                actions = stmt.get("Action", [])
                if isinstance(actions, str): actions = [actions]
                
                if not resource_arn: continue

                # [핵심] Resource가 "*" 인 경우 Action 분석 후 매칭
                if resource_arn == "*":
                    print(f"[DEBUG] Resource is '*', matching against {len(master_nodes)} nodes with actions: {actions}")
                    for target_id, target_node in master_nodes.items():
                        if target_id == src_id: 
                            print(f"[DEBUG] Skipping self-reference: {target_id}")
                            continue
                        
                        target_type = target_node.get("type", "").lower()
                        service_prefix = service_map.get(target_type)
                        
                        # 특수: sts:AssumeRole → iam_role 매칭
                        if any(act in actions for act in ["sts:AssumeRole", "sts:*", "*"]):
                            if target_type == "iam_role":
                                edge_id = f"edge:{src_id}:AssumeRole:{target_id}"
                                print(f"[DEBUG] MATCHED sts:AssumeRole! Creating edge: {edge_id} -> iam_role")
                                generated_edges.append({
                                    "id": edge_id,
                                    "relation": "AssumeRole",
                                    "src": src_id,
                                    "src_label": src_label,
                                    "dst": target_id,
                                    "dst_label": f"{target_node.get('type')}:{target_node.get('name')}",
                                    "directed": True,
                                    "conditions": ["sts:AssumeRole"]
                                })
                                continue
                        
                        if not service_prefix: 
                            print(f"[DEBUG] No service_prefix for type: {target_type}")
                            continue
                        
                        # Action 중 해당 서비스와 매칭되는 것이 있는지 확인 (IAM 제외)
                        if service_prefix and target_type not in ["iam_role", "iam_user"]:
                            is_match = any(
                                act == "*" or 
                                act.startswith(f"{service_prefix}:") or 
                                act == f"{service_prefix}:*"
                                for act in actions
                            )
                            
                            if is_match:
                                edge_id = f"edge:{src_id}:ActionMatch:{target_id}"
                                print(f"[DEBUG] MATCHED! Creating edge: {edge_id} -> {target_type}")
                                generated_edges.append({
                                    "id": edge_id,
                                    "relation": "AllowAccess",
                                    "src": src_id,
                                    "src_label": src_label,
                                    "dst": target_id,
                                    "dst_label": f"{target_node.get('type')}:{target_node.get('name')}",
                                    "directed": True,
                                    "conditions": actions # 허용된 전체 액션을 조건으로 기입
                                })
                            else:
                                print(f"[DEBUG] No match for {target_type} with actions {actions}")
                        elif target_type in ["iam_role", "iam_user"]:
                            print(f"[DEBUG] Skipping IAM resource (non-AssumeRole): {target_type}")
                    continue

                arns = resource_arn if isinstance(resource_arn, list) else [resource_arn]
                for arn in arns:
                    # 1. 기존 노드 중 ARN 매칭 확인
                    dst_node = next((n for n in master_nodes.values() if n.get("arn") == arn), None)
                    
                    # 2. 없으면 가상 노드(Placeholder) 생성
                    if not dst_node:
                        dst_node = self._create_placeholder_node(arn, account_id)
                        master_nodes[dst_node["id"]] = dst_node

                    # 3. 엣지 생성
                    relation = f"{stmt.get('Effect', 'Allow')}Access"
                    edge_id = f"edge:{src_id}:{relation}:{dst_node['id']}"
                    
                    generated_edges.append({
                        "id": edge_id,
                        "relation": relation,
                        "src": src_id,
                        "src_label": src_label,
                        "dst": dst_node["id"],
                        "dst_label": f"{dst_node['type']}:{dst_node['name']}",
                        "directed": True,
                        "conditions": stmt.get("Action", [])
                    })
        return generated_edges

    def _create_placeholder_node(self, arn: str, account_id: str) -> Dict[str, Any]:
        """ARN을 분석하여 존재하지 않는 리소스를 위한 가상 노드 생성"""
        # ARN 파싱 (arn:aws:service:region:account:resource)
        parts = arn.split(":")
        service = parts[2] if len(parts) > 2 else "unknown"
        region = parts[3] if len(parts) > 3 and parts[3] else "global"
        
        # 이름 추출 (마지막 섹션의 / 이후)
        res_name = parts[-1].split("/")[-1] if parts else "Unknown-Resource"
        
        # 우리 팀의 ID 규칙 적용
        virtual_id = f"{account_id}:{region}:{service}:{res_name}"
        
        return {
            "id": virtual_id,
            "type": service,
            "name": res_name,
            "arn": arn,
            "region": region,
            "properties": {
                "status": "placeholder",
                "exists_in_infra": False,
                "reason": "Created from CLI policy reference"
            }
        }

    # --- 기존 Merge 헬퍼 함수들 (유지) ---
    def _merge_graph_to_master(self, master_nodes, master_edges, sub_graph):
        for n in sub_graph.get("nodes", []):
            n_id = n.get("id")
            master_nodes[n_id] = self._merge_nodes(master_nodes.get(n_id, {}), n)
        for e in sub_graph.get("edges", []):
            e_id = e.get("id")
            master_edges[e_id] = self._merge_edges(master_edges.get(e_id, {}), e)

    def _merge_nodes(self, old: Dict[str, Any], new: Dict[str, Any]) -> Dict[str, Any]:
        merged = dict(old)
        for key in ["type", "name", "arn", "region"]:
            if not merged.get(key) and new.get(key):
                merged[key] = new[key]
        old_props = old.get("properties", {})
        new_props = new.get("properties", {})
        merged_props = {**old_props}
        for k, v in new_props.items():
            if k not in merged_props:
                merged_props[k] = v
            else:
                merged_props[k] = self._merge_property_value(merged_props[k], v)
        merged["properties"] = merged_props
        return merged

    def _merge_property_value(self, old_value: Any, new_value: Any) -> Any:
        if isinstance(old_value, dict) and isinstance(new_value, dict):
            merged = dict(old_value)
            for k, v in new_value.items():
                merged[k] = self._merge_property_value(merged.get(k), v) if k in merged else v
            return merged
        if isinstance(old_value, list) and isinstance(new_value, list):
            return list(set(map(str, old_value)) | set(map(str, new_value)))
        return new_value

    def _merge_edges(self, old: Dict[str, Any], new: Dict[str, Any]) -> Dict[str, Any]:
        merged = {**old, **new}
        return merged