import sys
import os
import json 
from collectors.collector_handler import handler as run_collectors
from collectors.cli_handler import run_cli_collector
from normalizers.normalizer_handler import run_normalizers
from graph_builder.graph_handler import GraphAssembler
from filters.filter_handler import run_filters    
from filters.filtering_handler import run_filtering 

def lambda_handler(event, context):
    cli_input = event.get("cli_input", "")
    account_id = event.get("account_id", "123456789012")

    # 데이터 수집 및 정규화
    cli_graph = run_cli_collector(cli_input, account_id)
    raw_data = run_collectors(event, context)
    normalized_data = run_normalizers(raw_data)

    # 그래프 조립 및 연결
    assembler = GraphAssembler()
    full_graph = assembler.assemble([normalized_data], cli_graph=cli_graph)
    
    # 필터링 및 필드 정제
    if cli_graph.get("nodes"):
        start_id = cli_graph["nodes"][0].get("node_id") or cli_graph["nodes"][0].get("id")
        sub_graph = run_filters(full_graph, start_id)
        final_ai_graph = run_filtering(sub_graph, start_id)
    else:
        final_ai_graph = full_graph
   
    # 지정 경로에 파일 덮어쓰기
    target_path = os.path.expanduser("~/ai_web-ui/backend/json/pandyo/search_pandyo.json")
    
    try:
        os.makedirs(os.path.dirname(target_path), exist_ok=True)
        with open(target_path, "w", encoding="utf-8") as f:
            json.dump(final_ai_graph, f, ensure_ascii=False, indent=2)
        save_status = f"Success: File overwritten at {target_path}"
    except Exception as e:
        save_status = f"Fail: {str(e)}"
        print(f"Error saving file: {e}")
        
    return {
        "statusCode": 200,
        "body": {
            "message": "Pipeline Completed",
            "save_status": save_status,
            "data": final_ai_graph
        }
    }