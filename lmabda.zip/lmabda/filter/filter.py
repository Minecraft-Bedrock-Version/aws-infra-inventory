from typing import Dict, List, Set

#graph에서 cli로 생성된 node와 간접/직접적으로 연결된 node, edge 찾는 함수
def extract_connected_subgraph( #인자값으로 node, edge와 기준으로 탐색할 start node id를 사용
    graph_nodes: List[Dict], 
    graph_edges: List[Dict],
    start_node_id: str,
):

    node_index = {n["node_id"]: n for n in graph_nodes}

    visited_nodes: Set[str] = set()
    visited_edges: Set[str] = set()

    queue: List[str] = [start_node_id]

    while queue:
        current_node_id = queue.pop(0)

        if current_node_id in visited_nodes:
            continue

        visited_nodes.add(current_node_id)

        for edge in graph_edges:
            edge_id = edge.get("id")
            src = edge.get("src")
            dst = edge.get("dst")

            if edge_id in visited_edges:
                continue

            if src == current_node_id or dst == current_node_id:
                visited_edges.add(edge_id)

                other_node_id = dst if src == current_node_id else src

                if other_node_id not in visited_nodes:
                    queue.append(other_node_id)

    connected_nodes = [
        node_index[nid]
        for nid in visited_nodes
        if nid in node_index
    ]

    connected_edges = [
        edge
        for edge in graph_edges
        if edge.get("id") in visited_edges
    ]

    return {
        "nodes": connected_nodes,
        "edges": connected_edges,
    }

#cli로 생성한 node의 id
start_node_id = "288528695623:global:iam_user:AIDAUGLNGQFDSPIKJRTZI"

#graph의 ndoe와 edge들
graph_data={
    "nodes":[],
    "edges":[]
}

#함수 호출 (인자값으로 node, edge와 기준으로 탐색할 start node id를 사용)
result = extract_connected_subgraph(
    graph_nodes=graph_data["nodes"],
    graph_edges=graph_data["edges"],
    start_node_id=start_node_id,
)

#결과 출력
print("Nodes:", len(result["nodes"]))
print("Edges:", len(result["edges"]))

print("Nodes:", result["nodes"])
print("Edges:", result["edges"])