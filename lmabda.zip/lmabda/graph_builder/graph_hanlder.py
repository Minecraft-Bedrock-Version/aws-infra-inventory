from datetime import datetime, timezone
from typing import List, Dict, Any

class GraphAssembler:

    def assemble(self, resource_graphs: List[Dict[str, Any]], cli_graph: Dict[str, Any] = None) -> Dict[str, Any]:
        master_nodes: Dict[str, Dict[str, Any]] = {}
        master_edges: Dict[str, Dict[str, Any]] = {}

        account_id = None
        collected_at_list = []

        # 1. 기존 인프라 그래프들 병합 
        graphs_to_process = list(resource_graphs)
        if cli_graph:
            graphs_to_process.append(cli_graph)
            
        for graph in graphs_to_process:
            if not account_id and graph.get("account_id"):
                account_id = graph.get("account_id")

            if graph.get("collected_at"):
                collected_at_list.append(graph["collected_at"])

            # 노드 병합 처리
            for node in graph.get("nodes", []):
            
                node_id = node.get("id") or node.get("node_id")
                if not node_id:
                    continue  

                if node_id not in master_nodes:
                    master_nodes[node_id] = node
                else:
                    existing_node = master_nodes[node_id]
                    merged_node = self._merge_nodes(existing_node, node)
                    master_nodes[node_id] = merged_node

            # 엣지 병합 처리
            for edge in graph.get("edges", []):
                edge_id = edge.get("id")
                if not edge_id:
                    continue  

                if edge_id not in master_edges:
                    master_edges[edge_id] = edge
                else:
                    existing_edge = master_edges[edge_id]
                    merged_edge = self._merge_edges(existing_edge, edge)
                    master_edges[edge_id] = merged_edge

        # 2. CLI 노드 기반 관계(Edge) 생성
        if cli_graph:
            for node in cli_graph.get("nodes", []):
                # IAM User 노드라면 내부의 정책을 읽어 엣지를 만듭니다.
                if node.get("node_type") == "iam_user":
                    new_edges = self._create_edges_from_iam_policy(node)
                    for e in new_edges:
                        master_edges[e["id"]] = e


        if collected_at_list:
            final_collected_at = max(collected_at_list)
        else:
            final_collected_at = datetime.now(timezone.utc).isoformat()

        output_graph = {
            "schema_version": "1.0",        
            "collected_at": final_collected_at,
            "account_id": account_id,
            "nodes": list(master_nodes.values()),
            "edges": list(master_edges.values())
        }

        return output_graph

    def _create_edges_from_iam_policy(self, user_node: Dict[str, Any]) -> List[Dict[str, Any]]:
        generated_edges = []
        user_id = user_node.get("node_id") or user_node.get("id")
        
        attributes = user_node.get("attributes", {})
        inline_policies = attributes.get("inline_policies", [])

        for policy in inline_policies:
            policy_name = policy.get("PolicyName", "Unknown")
            for stmt in policy.get("Statement", []):

                resource_arn = stmt.get("Resource")
                actions = stmt.get("Action", [])
                effect = stmt.get("Effect", "Allow")

                if resource_arn and resource_arn != "*":
                    target_arns = resource_arn if isinstance(resource_arn, list) else [resource_arn]
                    
                    for arn in target_arns:
                        edge_id = f"edge:{user_id}:to:{arn}"
                        generated_edges.append({
                            "id": edge_id,
                            "src": user_id,
                            "dst": arn,  # 이 ARN이 기존 인프라 노드의 ID와 일치해야 연결됨
                            "relation": f"{effect}Access",
                            "properties": {
                                "policy_name": policy_name,
                                "actions": actions
                            }
                        })
        return generated_edges

    def _merge_nodes(self, old: Dict[str, Any], new: Dict[str, Any]) -> Dict[str, Any]:

        merged = dict(old)

        for key in ["type", "name", "arn", "region"]:
            if not merged.get(key) and new.get(key):
                merged[key] = new[key]

        old_props = old.get("properties", {})
        new_props = new.get("properties", {})

        merged_props = dict(old_props)

        for prop_key, prop_value in new_props.items():
            if prop_key not in merged_props:
                merged_props[prop_key] = prop_value
            else:
                merged_props[prop_key] = self._merge_property_value(
                    merged_props[prop_key],
                    prop_value
                )

        merged["properties"] = merged_props

        return merged

    def _merge_property_value(self, old_value: Any, new_value: Any) -> Any:

        if isinstance(old_value, dict) and isinstance(new_value, dict):
            merged = dict(old_value)
            for k, v in new_value.items():
                if k not in merged:
                    merged[k] = v
                else:
                    merged[k] = self._merge_property_value(merged[k], v)
            return merged

        if isinstance(old_value, list) and isinstance(new_value, list):
            return list({*old_value, *new_value})
            
        return new_value

    def _merge_edges(self, old: Dict[str, Any], new: Dict[str, Any]) -> Dict[str, Any]:

        merged = dict(old)

        for key in ["relation", "src", "dst", "src_label", "dst_label", "directed"]:
            if not merged.get(key) and new.get(key):
                merged[key] = new[key]

        old_conditions = old.get("conditions", [])
        new_conditions = new.get("conditions", [])

        if old_conditions or new_conditions:
            merged_conditions = []

            seen = set()
            for cond in old_conditions + new_conditions:
                key = f"{cond.get('key')}={cond.get('value')}"
                if key not in seen:
                    seen.add(key)
                    merged_conditions.append(cond)

            merged["conditions"] = merged_conditions

        return merged
