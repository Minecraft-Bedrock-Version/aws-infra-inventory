"""
테스트 스크립트: process_simulation 함수 검증

이 스크립트는 process_simulation 함수가 제대로 작동하는지 테스트합니다.
"""

import json
import sys
import os

# 프로젝트 루트를 sys.path에 추가
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.handler.lambda_handler import process_simulation


def test_basic_simulation():
    """기본적인 시뮬레이션 테스트"""
    print("=" * 80)
    print("TEST 1: Basic IAM User Policy Simulation")
    print("=" * 80)
    
    # 테스트용 CLI 스크립트
    cli_script = """aws iam put-user-policy --user-name test-user --policy-name TestS3Policy --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["s3:GetObject","s3:PutObject"],"Resource":"*"}]}'"""
    
    # process_simulation 실행
    try:
        result = process_simulation(
            cli_script=cli_script,
            account_id="123456789012",
            region="us-east-1"
        )
        
        print("\n✅ Test passed!")
        print(f"\nResult Summary:")
        print(f"  - Schema Version: {result.get('schema_version')}")
        print(f"  - Account ID: {result.get('account_id')}")
        print(f"  - Total Nodes: {len(result.get('nodes', []))}")
        print(f"  - Total Edges: {len(result.get('edges', []))}")
        
        # 메타데이터 출력
        metadata = result.get('metadata', {})
        print(f"\nMetadata:")
        print(f"  - Actual Nodes: {metadata.get('actual_nodes')}")
        print(f"  - Proposed Nodes: {metadata.get('proposed_nodes')}")
        print(f"  - Total Nodes: {metadata.get('total_nodes')}")
        print(f"  - Total Edges: {metadata.get('total_edges')}")
        
        # Proposed 노드 확인
        proposed_nodes = [
            n for n in result.get('nodes', []) 
            if n.get('properties', {}).get('status') == 'proposed'
        ]
        
        print(f"\n📍 Proposed Nodes Found: {len(proposed_nodes)}")
        for node in proposed_nodes:
            print(f"  - {node.get('type')}: {node.get('name')} (ID: {node.get('id')})")
            print(f"    Status: {node.get('properties', {}).get('status')}")
            print(f"    Proposed At: {node.get('properties', {}).get('proposed_at')}")
        
        # 결과를 파일로 저장
        output_path = "test_simulation_result.json"
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"\n💾 Full result saved to: {output_path}")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_empty_cli():
    """빈 CLI 입력 테스트"""
    print("\n" + "=" * 80)
    print("TEST 2: Empty CLI Script")
    print("=" * 80)
    
    try:
        result = process_simulation(
            cli_script="",
            account_id="123456789012",
            region="us-east-1"
        )
        
        print("\n✅ Test passed!")
        print(f"  - Total Nodes: {len(result.get('nodes', []))}")
        print(f"  - Total Edges: {len(result.get('edges', []))}")
        
        # 빈 CLI면 proposed 노드가 0개여야 함
        proposed_count = result.get('metadata', {}).get('proposed_nodes', 0)
        assert proposed_count == 0, f"Expected 0 proposed nodes, got {proposed_count}"
        
        print(f"  - Proposed Nodes: {proposed_count} ✓")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_assume_role_cli():
    """AssumeRole 권한이 있는 CLI 테스트"""
    print("\n" + "=" * 80)
    print("TEST 3: IAM User with AssumeRole Permission")
    print("=" * 80)
    
    cli_script = """aws iam put-user-policy --user-name admin-user --policy-name AssumeRolePolicy --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":"sts:AssumeRole","Resource":"*"}]}'"""
    
    try:
        result = process_simulation(
            cli_script=cli_script,
            account_id="123456789012",
            region="us-east-1"
        )
        
        print("\n✅ Test passed!")
        
        # Proposed 노드와 엣지 확인
        proposed_nodes = [
            n for n in result.get('nodes', []) 
            if n.get('properties', {}).get('status') == 'proposed'
        ]
        
        # AssumeRole 관련 엣지 찾기
        assume_role_edges = [
            e for e in result.get('edges', [])
            if 'ASSUME' in e.get('relation', '').upper()
        ]
        
        print(f"\n  - Proposed Nodes: {len(proposed_nodes)}")
        print(f"  - AssumeRole Edges: {len(assume_role_edges)}")
        
        for edge in assume_role_edges[:3]:  # 처음 3개만 출력
            print(f"    • {edge.get('src')} --[{edge.get('relation')}]--> {edge.get('dst')}")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    print("\n🧪 Starting process_simulation Tests\n")
    
    results = []
    
    # 테스트 실행
    results.append(("Basic Simulation", test_basic_simulation()))
    results.append(("Empty CLI", test_empty_cli()))
    results.append(("AssumeRole CLI", test_assume_role_cli()))
    
    # 결과 요약
    print("\n" + "=" * 80)
    print("TEST SUMMARY")
    print("=" * 80)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} - {test_name}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 All tests passed!")
        sys.exit(0)
    else:
        print("\n⚠️  Some tests failed")
        sys.exit(1)
