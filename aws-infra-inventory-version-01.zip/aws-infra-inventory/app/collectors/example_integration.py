"""
통합 예시: cliCreate.py → CLI Parser Registry → 시각화 파이프라인

이 스크립트는 실제 프로덕션 환경에서 어떻게 사용되는지 보여줍니다:
1. 프론트엔드 요청 시뮬레이션
2. cliCreate.py로 CLI 명령어 생성
3. cli_parsers (새 파서 시스템)로 Node/Edge 데이터 생성
4. (선택) 정규화 및 그래프 빌더 파이프라인 연결
"""

import sys
import os
import json

# cliCreate 모듈 임포트를 위한 경로 설정
sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", "..", "ai_web-ui", "backend", "cliCreate"))

from cliCreate import generate_cli_commands

# 새로운 파서 레지스트리 시스템 사용
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from app.collectors.cli_parsers import parse_cli


def print_section(title: str):
    """섹션 구분선 출력"""
    print("\n" + "=" * 80)
    print(f"  {title}")
    print("=" * 80 + "\n")


def simulate_frontend_request():
    """프론트엔드 요청을 시뮬레이션"""
    return {
        "resource": "user",
        "selectedEntity": "data-analyst",
        "activePolicies": {
            "s3": ["GetObject", "ListBucket", "PutObject"],
            "athena": ["StartQueryExecution", "GetQueryResults"],
            "glue": ["GetTable", "GetDatabase"]
        }
    }


def main():
    print_section("1단계: 프론트엔드 요청 시뮬레이션")
    
    # 1. 프론트엔드에서 전송한 state
    state = simulate_frontend_request()
    print("프론트엔드 요청 데이터:")
    print(json.dumps(state, indent=2, ensure_ascii=False))
    
    print_section("2단계: cliCreate.py - CLI 명령어 생성")
    
    # 2. cliCreate.py가 CLI 명령어 생성
    cli_commands = generate_cli_commands(state)
    print("생성된 CLI 명령어:")
    print(cli_commands)
    
    print_section("3단계: CLI Parser Registry - Node/Edge 데이터 생성")
    
    # 3. 새로운 파서 레지스트리로 시각화용 데이터 구조로 변환
    account_id = "123456789012"
    result = parse_cli(cli_commands, account_id=account_id)
    
    print("생성된 데이터 구조:")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    print_section("4단계: 데이터 검증 및 요약")
    
    # 4. 결과 검증
    print(f"✅ 총 노드 수: {len(result['nodes'])}")
    print(f"✅ 총 엣지 수: {len(result['edges'])}")
    print(f"✅ Account ID: {result['account_id']}")
    print(f"✅ 수집 시각: {result['collected_at']}")
    
    if result['nodes']:
        node = result['nodes'][0]
        print(f"\n[노드 상세 정보]")
        print(f"  - 타입: {node['node_type']}")
        print(f"  - 이름: {node['name']}")
        print(f"  - ARN: {node['attributes']['arn']}")
        print(f"  - Inline Policies: {len(node['attributes']['inline_policies'])}개")
        print(f"  - Attached Policies: {len(node['attributes']['attached_policies'])}개")
        
        if node['attributes']['inline_policies']:
            policy = node['attributes']['inline_policies'][0]
            print(f"\n[정책 상세 - {policy['PolicyName']}]")
            for stmt in policy['Statement']:
                print(f"  - Effect: {stmt['Effect']}")
                print(f"  - Actions: {', '.join(stmt['Action'][:3])}{'...' if len(stmt['Action']) > 3 else ''}")
                print(f"  - Resource: {stmt['Resource']}")
    
    print_section("5단계: 다음 파이프라인 연결 가능")
    
    print("이제 이 데이터를 다음 단계로 전달할 수 있습니다:")
    print("  → normalizer (정규화)")
    print("  → graph_builder (그래프 구조 생성)")
    print("  → filter (필터링)")
    print("  → 프론트엔드 (D3.js, Cytoscape.js 등으로 시각화)")
    
    # 파이프라인 예시 (주석 처리)
    print("\n[파이프라인 연결 예시 코드]")
    print("""
    # from app.normalizers.iam_user_normalizer import normalize_iam_users
    # from app.graph_builder.iam_user_graph import transform_iam_users
    
    # normalized = normalize_iam_users(result['nodes'], account_id)
    # graph_data = transform_iam_users({"nodes": normalized, "account_id": account_id})
    # 
    # # 프론트엔드로 반환
    # return {
    #     "nodes": graph_data["nodes"],
    #     "edges": graph_data["edges"]
    # }
    """)
    
    print_section("완료!")
    print("✨ CLI 명령어 → 시각화 데이터 변환이 성공적으로 완료되었습니다!")


if __name__ == "__main__":
    main()
