# CliToNode.py 사용 가이드

## 개요

`CliToNode.py`는 AWS CLI 명령어 문자열을 파싱하여 AWS 인프라 시각화에 필요한 **Node(노드)**와 **Edge(엣지)** 데이터 구조로 변환하는 파이썬 모듈입니다.

### 주요 기능

- ✅ AWS IAM CLI 명령어 파싱 (User, Role, Group)
- ✅ 정책(Policy) 문서 파싱 (Inline Policy, Managed Policy)
- ✅ Node 데이터 구조 생성 (시각화용)
- ✅ Edge 데이터 구조 생성 (관계 표현)
- ✅ 여러 명령어 동시 처리 (줄바꿈으로 구분)
- ✅ `cliCreate.py` 출력 포맷 완벽 호환

---

## 설치 및 임포트

```python
from app.collectors.CliToNode import CliToNode, cli_to_nodes
```

---

## 사용 방법

### 1. 기본 사용법 (편의 함수)

가장 간단한 방법은 `cli_to_nodes()` 함수를 사용하는 것입니다:

```python
from app.collectors.CliToNode import cli_to_nodes

# cliCreate.py에서 생성된 CLI 문자열
cli_text = """aws iam create-user --user-name test-developer
aws iam put-user-policy --user-name test-developer --policy-name GeneratedPolicy --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["s3:GetObject","s3:ListBucket"],"Resource":"*"}]}'"""

# 파싱
result = cli_to_nodes(cli_text, account_id="123456789012")

# 결과 확인
print(result["nodes"])  # 노드 리스트
print(result["edges"])  # 엣지 리스트
```

### 2. 클래스 사용법 (고급)

더 세밀한 제어가 필요한 경우 `CliToNode` 클래스를 직접 사용할 수 있습니다:

```python
from app.collectors.CliToNode import CliToNode

parser = CliToNode(account_id="123456789012", region="global")
result = parser.parse(cli_text)
```

---

## 입력 포맷

### cliCreate.py 호환 포맷

`cliCreate.py`가 생성하는 CLI 명령어는 다음 규칙을 따릅니다:

1. **정책 문서(JSON)는 작은따옴표(`'`)로 감싸짐**
2. **JSON 내부는 공백이 제거됨** (`json.dumps(..., separators=(',', ':'))`)
3. **여러 명령어는 줄바꿈(`\n`)으로 구분**

예시:
```text
aws iam create-user --user-name test-developer
aws iam put-user-policy --user-name test-developer --policy-name GeneratedPolicy --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["s3:GetObject","s3:ListBucket","ec2:DescribeInstances"],"Resource":"*"}]}'
```

---

## 지원하는 CLI 명령어

### IAM User 관련
- `aws iam create-user --user-name <이름>`
- `aws iam put-user-policy --user-name <이름> --policy-name <정책이름> --policy-document '<JSON>'`
- `aws iam attach-user-policy --user-name <이름> --policy-arn <ARN>`

### IAM Role 관련
- `aws iam create-role --role-name <이름> --assume-role-policy-document '<JSON>'`
- `aws iam put-role-policy --role-name <이름> --policy-name <정책이름> --policy-document '<JSON>'`
- `aws iam attach-role-policy --role-name <이름> --policy-arn <ARN>`

### IAM Group 관련
- `aws iam create-group --group-name <이름>`
- `aws iam put-group-policy --group-name <이름> --policy-name <정책이름> --policy-document '<JSON>'`
- `aws iam attach-group-policy --group-name <이름> --policy-arn <ARN>`

---

## 출력 데이터 구조

### 전체 구조

```json
{
  "schema_version": "1.0",
  "collected_at": "2026-01-29T19:28:32.044249+00:00",
  "account_id": "123456789012",
  "nodes": [...],
  "edges": [...]
}
```

### Node 구조 예시

```json
{
  "node_type": "iam_user",
  "node_id": "iam_user:123456789012:test-developer",
  "resource_id": "test-developer",
  "name": "test-developer",
  "attributes": {
    "arn": "arn:aws:iam::123456789012:user/test-developer",
    "create_date": "2026-01-29T19:28:32.044249+00:00",
    "attached_policies": [],
    "inline_policies": [
      {
        "PolicyName": "GeneratedPolicy",
        "Statement": [
          {
            "Effect": "Allow",
            "Action": ["s3:GetObject", "s3:ListBucket"],
            "Resource": ["*"]
          }
        ]
      }
    ],
    "group_policies": []
  },
  "raw_refs": {
    "source": ["cli:aws iam create-user", "cli:aws iam put-user-policy"],
    "collected_at": "2026-01-29T19:28:32.044249+00:00"
  }
}
```

### Edge 구조 예시

#### CAN_ASSUME_ROLE 엣지
User/Role이 다른 Role을 Assume할 수 있는 권한:

```json
{
  "id": "edge:admin-user:CAN_ASSUME_ROLE:dev-role",
  "relation": "CAN_ASSUME_ROLE",
  "src": "iam_user:123456789012:admin-user",
  "src_label": "iam_user:admin-user",
  "dst": "iam_role:123456789012:dev-role",
  "dst_label": "iam_role:dev-role",
  "directed": true,
  "conditions": [{"key": "policy_type", "value": "inline"}]
}
```

#### HAS_POLICY 엣지
Entity가 Managed Policy를 가지고 있음:

```json
{
  "id": "edge:power-user:HAS_POLICY:PowerUserAccess",
  "relation": "HAS_POLICY",
  "src": "iam_user:123456789012:power-user",
  "src_label": "iam_user:power-user",
  "dst": "aws:global:iam_policy:PowerUserAccess",
  "dst_label": "iam_policy:PowerUserAccess",
  "directed": true
}
```

---

## 사용 예시

### 예시 1: User 생성 + S3 권한 부여

```python
cli_text = """aws iam create-user --user-name s3-user
aws iam put-user-policy --user-name s3-user --policy-name S3ReadOnly --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["s3:GetObject","s3:ListBucket"],"Resource":"*"}]}'"""

result = cli_to_nodes(cli_text, account_id="123456789012")
# → 1개의 User 노드 생성, inline_policies에 S3ReadOnly 정책 포함
```

### 예시 2: Lambda Role 생성 + Trust Policy + 실행 권한

```python
cli_text = """aws iam create-role --role-name lambda-exec-role --assume-role-policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"lambda.amazonaws.com"},"Action":"sts:AssumeRole"}]}'
aws iam put-role-policy --role-name lambda-exec-role --policy-name LambdaLogs --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["logs:CreateLogGroup","logs:CreateLogStream","logs:PutLogEvents"],"Resource":"*"}]}'"""

result = cli_to_nodes(cli_text, account_id="123456789012")
# → 1개의 Role 노드 생성, assume_role_policy와 inline_policies 포함
```

### 예시 3: User가 Role Assume 가능 (엣지 생성)

```python
cli_text = """aws iam create-user --user-name admin
aws iam put-user-policy --user-name admin --policy-name AssumeDevRole --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":"sts:AssumeRole","Resource":"arn:aws:iam::123456789012:role/dev-role"}]}'"""

result = cli_to_nodes(cli_text, account_id="123456789012")
# → 1개의 User 노드 + 1개의 CAN_ASSUME_ROLE 엣지 생성
print(result["edges"][0]["relation"])  # "CAN_ASSUME_ROLE"
```

### 예시 4: AWS Managed Policy 연결

```python
cli_text = """aws iam create-user --user-name power-user
aws iam attach-user-policy --user-name power-user --policy-arn arn:aws:iam::aws:policy/PowerUserAccess"""

result = cli_to_nodes(cli_text, account_id="123456789012")
# → 1개의 User 노드 + 1개의 HAS_POLICY 엣지 생성
print(result["edges"][0]["dst"])  # "aws:global:iam_policy:PowerUserAccess"
```

### 예시 5: 여러 리소스 한번에 생성

```python
cli_text = """aws iam create-user --user-name user1
aws iam create-user --user-name user2
aws iam create-role --role-name role1 --assume-role-policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"lambda.amazonaws.com"},"Action":"sts:AssumeRole"}]}'
aws iam create-group --group-name developers"""

result = cli_to_nodes(cli_text, account_id="123456789012")
# → 4개의 노드 생성 (User 2개, Role 1개, Group 1개)
print(len(result["nodes"]))  # 4
```

---

## 엣지 생성 규칙

### 1. CAN_ASSUME_ROLE
**생성 조건**: Inline Policy의 Statement에서 `sts:AssumeRole` 액션이 있고, Resource에 특정 Role ARN이 지정된 경우

**예시 정책**:
```json
{
  "Effect": "Allow",
  "Action": "sts:AssumeRole",
  "Resource": "arn:aws:iam::123456789012:role/dev-role"
}
```

**생성되는 엣지**:
- `relation`: `"CAN_ASSUME_ROLE"`
- `src`: 정책을 가진 User/Role의 node_id
- `dst`: Resource에 지정된 Role의 node_id
- `directed`: `true`

**주의사항**: Resource가 `"*"`인 경우 엣지를 생성하지 않음 (너무 많은 엣지 생성 방지)

### 2. HAS_POLICY
**생성 조건**: `attach-*-policy` 명령어로 Managed Policy를 연결한 경우

**예시 명령어**:
```bash
aws iam attach-user-policy --user-name test-user --policy-arn arn:aws:iam::aws:policy/ReadOnlyAccess
```

**생성되는 엣지**:
- `relation`: `"HAS_POLICY"`
- `src`: Entity의 node_id
- `dst`: Policy의 node_id (AWS Managed는 "aws:", Customer Managed는 "account_id:")
- `directed`: `true`

---

## 기존 함수 호환성

기존 `cli_put_user_policy_to_iam_user_json()` 함수는 그대로 유지되어 하위 호환성을 보장합니다:

```python
from app.collectors.CliToNode import cli_put_user_policy_to_iam_user_json

cli_text = """aws iam put-user-policy --user-name legacy-user --policy-name Policy1 --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["s3:GetObject"],"Resource":"*"}]}'"""

result = cli_put_user_policy_to_iam_user_json(cli_text, account_id="123456789012")
# 기존과 동일한 형태로 동작
```

---

## 테스트

테스트 스크립트를 실행하여 모든 기능이 정상 작동하는지 확인할 수 있습니다:

```bash
cd app/collectors
python test_CliToNode.py
```

테스트는 다음 8가지 시나리오를 검증합니다:
1. User 생성 + Inline Policy
2. Role 생성 + Trust Policy + Inline Policy
3. Group 생성 + Inline Policy
4. User with AssumeRole 권한 (엣지 생성)
5. Managed Policy 연결 (엣지 생성)
6. 여러 리소스 동시 생성
7. 기존 함수 호환성
8. create 없이 policy만 부여

---

## 통합 예시 (프론트엔드 → 백엔드 → 시각화)

### 1단계: 프론트엔드에서 요청

```javascript
const state = {
  resource: "user",
  selectedEntity: "developer-1",
  activePolicies: {
    s3: ["GetObject", "ListBucket"],
    ec2: ["DescribeInstances"]
  }
};

fetch("/cli_create", {
  method: "POST",
  body: JSON.stringify({ state })
});
```

### 2단계: cliCreate.py가 CLI 생성

```python
# cliCreate.py
cli_commands = generate_cli_commands(state)
# 반환값:
# aws iam create-user --user-name developer-1
# aws iam put-user-policy --user-name developer-1 --policy-name GeneratedPolicy --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["s3:GetObject","s3:ListBucket","ec2:DescribeInstances"],"Resource":"*"}]}'
```

### 3단계: CliToNode.py가 Node/Edge 생성

```python
from app.collectors.CliToNode import cli_to_nodes

result = cli_to_nodes(cli_commands, account_id="123456789012")
# result["nodes"] → 시각화용 노드 데이터
# result["edges"] → 시각화용 엣지 데이터
```

### 4단계: 시각화 렌더링

```python
# graph_builder or normalizer에서 사용
nodes = result["nodes"]
edges = result["edges"]

# D3.js, Cytoscape.js 등으로 그래프 렌더링
```

---

## API 레퍼런스

### `cli_to_nodes(cli_text, account_id, region="global")`

CLI 명령어 문자열을 Node/Edge 데이터로 변환

**Parameters:**
- `cli_text` (str): AWS CLI 명령어 문자열 (줄바꿈으로 구분)
- `account_id` (str): AWS 계정 ID
- `region` (str, optional): 리전 (기본값: "global")

**Returns:**
- dict: `{"schema_version": "1.0", "nodes": [...], "edges": [...], "account_id": "...", "collected_at": "..."}`

**Example:**
```python
result = cli_to_nodes(
    "aws iam create-user --user-name test", 
    account_id="123456789012"
)
```

---

### `CliToNode(account_id, region="global")`

CLI 파서 클래스

**Parameters:**
- `account_id` (str): AWS 계정 ID
- `region` (str, optional): 리전 (기본값: "global")

**Methods:**
- `parse(cli_text)`: CLI 문자열을 파싱하여 결과 반환

**Example:**
```python
parser = CliToNode(account_id="123456789012")
result = parser.parse(cli_text)
```

---

## 문제 해결

### Q: JSON 파싱 에러가 발생해요
**A:** CLI 명령어의 policy-document가 올바른 JSON 형식인지 확인하세요. `cliCreate.py`가 생성한 포맷(작은따옴표로 감싸짐)이 맞는지 확인하세요.

### Q: 엣지가 생성되지 않아요
**A:** 
1. `sts:AssumeRole` 권한의 경우 Resource에 구체적인 Role ARN이 있어야 합니다. `"*"`는 엣지 생성 안 됨.
2. Managed Policy 연결은 `attach-*-policy` 명령어를 사용해야 합니다.

### Q: 노드가 중복 생성돼요
**A:** 같은 entity에 대해 create 명령어를 여러 번 실행하면 중복 노드가 생성됩니다. 내부적으로 `entities` 딕셔너리로 관리하므로, create 후 put/attach 순서로 명령어를 작성하면 중복이 방지됩니다.

---

## 변경 이력

### v1.0 (2026-01-29)
- 초기 버전 릴리스
- IAM User/Role/Group 지원
- Inline Policy 및 Managed Policy 지원
- CAN_ASSUME_ROLE, HAS_POLICY 엣지 지원
- cliCreate.py 새 포맷 호환 (작은따옴표, 공백 제거)

---

## 라이센스 및 기여

이 모듈은 `aws-infra-inventory` 프로젝트의 일부입니다.
