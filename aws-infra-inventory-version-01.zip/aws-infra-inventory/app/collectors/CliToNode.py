"""
LEGACY COMPATIBILITY WRAPPER

이 파일은 기존 코드와의 호환성을 위해 유지됩니다.
새 코드는 app.collectors.cli_parsers 모듈을 직접 사용하세요.

DEPRECATED: 이 함수 대신 다음을 사용하세요:
    from app.collectors.cli_parsers import parse_cli
    result = parse_cli(cli_text, account_id)
"""

from app.collectors.cli_parsers import parse_cli


def cli_put_user_policy_to_iam_user_json(
    cli_text: str,
    account_id: str = "string",
    collected_at: str = None,
    source_tag: str = "cli:aws iam put-user-policy",
) -> dict:
    """
    DEPRECATED: 하위 호환성을 위한 레거시 함수
    
    기존 코드에서 이 함수를 호출하는 경우를 위해 유지됩니다.
    내부적으로 새로운 파서 레지스트리 시스템을 사용합니다.
    
    Args:
        cli_text: AWS CLI 명령어 문자열
        account_id: AWS 계정 ID
        collected_at: (무시됨) 수집 시각
        source_tag: (무시됨) 소스 태그
    
    Returns:
        dict: 파싱된 노드/엣지 데이터
    
    Example:
        >>> result = cli_put_user_policy_to_iam_user_json(
        ...     cli_text="aws iam create-user --user-name developer",
        ...     account_id="123456789012"
        ... )
        >>> print(result["nodes"][0]["name"])
        developer
    
    Migration Guide:
        Old:
            from app.collectors.CliToNode import cli_put_user_policy_to_iam_user_json
            result = cli_put_user_policy_to_iam_user_json(cli_text, account_id)
        
        New:
            from app.collectors.cli_parsers import parse_cli
            result = parse_cli(cli_text, account_id)
    """
    # 새로운 파서 레지스트리로 위임
    return parse_cli(cli_text, account_id)


# 이전 유틸리티 함수들은 base_parser로 이동했습니다
# 필요한 경우 다음과 같이 import:
#   from app.collectors.cli_parsers.base_parser import BaseParser
#   normalized = BaseParser._collapse_cli(cli_text)
#   value = BaseParser._extract_flag_value(cli_line, "--flag")
