"""
간단한 테스트: AWS 자격 증명 없이 process_simulation 로직 검증

이 스크립트는 AWS API 호출을 모킹하여 핵심 로직만 테스트합니다.
"""

import json
import sys
import os

# 프로젝트 루트를 sys.path에 추가
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.collectors.cli_handler import run_cli_collector
from app.graph_builder.graph_handler import GraphAssembler


def test_cli_parsing_only():
    """CLI 파싱만 테스트 (AWS 연결 불필요)"""
    print("=" * 80)
    print("TEST 1: CLI Parsing Only (No AWS Required)")
    print("=" * 80)
    
    cli_script = """aws iam put-user-policy --user-name test-dev --policy-name S3ReadPolicy --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["s3:GetObject","s3:ListBucket"],"Resource":"*"}]}'"""
    
    account_id = "123456789012"
    
    # CLI 파싱  print(f"\n📝 Parsing CLI script...")
    cli_graph = run_cli_collector(cli_script, account_id)
    
    print(f"\n✅ CLI Parsing Success!")
    print(f"  - Nodes parsed: {len(cli_graph.get('nodes', []))}")
    
    # 노드 상세 정보
    for node in cli_graph.get("nodes", []):
        print(f"\n  📍 Node Details:")
        print(f"    - Type: {node.get('node_type')}")
        print(f"    - ID: {node.get('node_id')}")
        print(f"    - Name: {node.get('name')}")
        
        # 정책 정보
        inline_policies = node.get("attributes", {}).get("inline_policies", [])
        print(f"    - Inline Policies: {len(inline_policies)}")
        for policy in inline_policies:
            print(f"      • {policy.get('PolicyName')}")
            for stmt in policy.get("Statement", []):
                print(f"        - Effect: {stmt.get('Effect')}")
                print(f"        - Actions: {stmt.get('Action')}")
                print(f"        - Resource: {stmt.get('Resource')}")
    
    # 파일로 저장
    with open("cli_parsed_result.json", "w", encoding="utf-8") as f:
        json.dump(cli_graph, f, ensure_ascii=False, indent=2)
    
    print(f"\n💾 Saved to: cli_parsed_result.json")
    
    return True


def test_proposed_marking():
    """Proposed 상태 마킹 테스트"""
    print("\n" + "=" * 80)
    print("TEST 2: Proposed Node Marking")
    print("=" * 80)
    
    cli_script = """aws iam put-user-policy --user-name admin --policy-name FullAccess --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":"*","Resource":"*"}]}'"""
    
    account_id = "123456789012"
    
    # CLI 파싱
    cli_graph = run_cli_collector(cli_script, account_id)
    
    # 수동으로 proposed 마킹 (process_simulation에서 하는 것처럼)
    from datetime import datetime
    
    if cli_graph.get("nodes"):
        for node in cli_graph["nodes"]:
            if "attributes" not in node:
                node["attributes"] = {}
            node["attributes"]["status"] = "proposed"
            node["attributes"]["proposed_at"] = datetime.now().isoformat()
    
    print(f"\n✅ Proposed Marking Success!")
    
    # 확인
    for node in cli_graph.get("nodes", []):
        status = node.get("attributes", {}).get("status")
        proposed_at = node.get("attributes", {}).get("proposed_at")
        
        print(f"\n  📍 Node: {node.get('name')}")
        print(f"    - Status: {status}")
        print(f"    - Proposed At: {proposed_at}")
        
        assert status == "proposed", "Status should be 'proposed'"
        assert proposed_at is not None, "proposed_at should be set"
    
    print(f"\n✅ All nodes properly marked as proposed!")
    
    return True


def test_graph_assembly_with_mock_data():
    """모의 데이터로 그래프 조립 테스트"""
    print("\n" + "=" * 80)
    print("TEST 3: Graph Assembly with Mock Data")
    print("=" * 80)
    
    # 모의 실제 인프라 데이터 (빈 데이터)
    mock_resource_map = {
        "account_id": "123456789012",
        "iam_user": {"nodes": []},
        "iam_role": {"nodes": []},
        "vpc": {"nodes": []},
        "subnet": {"nodes": []},
    }
    
    # CLI 그래프
    cli_script = """aws iam put-user-policy --user-name test-user --policy-name TestPolicy --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":"s3:*","Resource":"*"}]}'"""
    
    cli_graph = run_cli_collector(cli_script, "123456789012")
    
    # Proposed 마킹
    from datetime import datetime
    for node in cli_graph.get("nodes", []):
        if "attributes" not in node:
            node["attributes"] = {}
        node["attributes"]["status"] = "proposed"
        node["attributes"]["proposed_at"] = datetime.now().isoformat()
    
    # 그래프 조립
    print(f"\n🔨 Assembling graph...")
    assembler = GraphAssembler()
    
    try:
        unified_graph = assembler.assemble(mock_resource_map, cli_graph)
        
        print(f"\n✅ Graph Assembly Success!")
        print(f"  - Total Nodes: {len(unified_graph.get('nodes', []))}")
        print(f"  - Total Edges: {len(unified_graph.get('edges', []))}")
        
        # Proposed 노드 확인
        proposed_nodes = [
            n for n in unified_graph.get("nodes", [])
            if n.get("properties", {}).get("status") == "proposed"
        ]
        
        print(f"\n  📍 Proposed nodes in final graph: {len(proposed_nodes)}")
        for node in proposed_nodes:
            print(f"    • {node.get('type')}: {node.get('name')}")
            print(f"      - Status: {node.get('properties', {}).get('status')}")
        
        # 결과 저장
        with open("mock_assembled_graph.json", "w", encoding="utf-8") as f:
            json.dump(unified_graph, f, ensure_ascii=False, indent=2)
        
        print(f"\n💾 Saved to: mock_assembled_graph.json")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Assembly failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_node_deduplication():
    """노드 중복 제거 테스트"""
    print("\n" + "=" * 80)
    print("TEST 4: Node Deduplication")
    print("=" * 80)
    
    # 같은 User에 대한 모의 실제 노드
    mock_existing_user = {
        "node_type": "iam_user",
        "node_id": "iam_user:123456789012:test-user",
        "name": "test-user",
        "attributes": {
            "arn": "arn:aws:iam::123456789012:user/test-user",
            "inline_policies": []  # 기존에는 정책 없음
        }
    }
    
    mock_resource_map = {
        "account_id": "123456789012",
        "iam_user": {
            "nodes": [mock_existing_user]
        }
    }
    
    # CLI에서 같은 User에 정책 추가
    cli_script = """aws iam put-user-policy --user-name test-user --policy-name NewPolicy --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":"ec2:*","Resource":"*"}]}'"""
    
    cli_graph = run_cli_collector(cli_script, "123456789012")
    
    print(f"\n  Before merge:")
    print(f"    - Existing infrastructure nodes: {len(mock_resource_map['iam_user']['nodes'])}")
    print(f"    - CLI proposed nodes: {len(cli_graph.get('nodes', []))}")
    
    # 조립
    assembler = GraphAssembler()
    unified_graph = assembler.assemble(mock_resource_map, cli_graph)
    
    # 중복 제거 확인
    all_node_ids = [n.get("id") or n.get("node_id") for n in unified_graph.get("nodes", [])]
    unique_ids = set(all_node_ids)
    
    print(f"\n  After merge:")
    print(f"    - Total nodes: {len(unified_graph.get('nodes', []))}")
    print(f"    - Unique node IDs: {len(unique_ids)}")
    
    assert len(all_node_ids) == len(unique_ids), "There should be no duplicate node IDs!"
    
    # test-user 노드가 하나만 있고, 정책이 병합되었는지 확인
    test_user_nodes = [
        n for n in unified_graph.get("nodes", [])
        if "test-user" in str(n.get("id") or n.get("name", ""))
    ]
    
    print(f"\n  📍 test-user nodes found: {len(test_user_nodes)}")
    assert len(test_user_nodes) == 1, "Should have exactly 1 test-user node (merged)"
    
    # 정책 확인
    user_node = test_user_nodes[0]
    policies = user_node.get("properties", {}).get("inline_policies", [])
    print(f"    - Inline policies: {len(policies)}")
    
    for policy in policies:
        print(f"      • {policy.get('PolicyName')}")
    
    print(f"\n✅ Node deduplication working correctly!")
    
    return True


if __name__ == "__main__":
    print("\n🧪 Starting Simple Tests (No AWS Credentials Required)\n")
    
    results = []
    
    # 테스트 실행
    try:
        results.append(("CLI Parsing", test_cli_parsing_only()))
    except Exception as e:
        print(f"❌ Test failed: {e}")
        results.append(("CLI Parsing", False))
    
    try:
        results.append(("Proposed Marking", test_proposed_marking()))
    except Exception as e:
        print(f"❌ Test failed: {e}")
        results.append(("Proposed Marking", False))
    
    try:
        results.append(("Graph Assembly", test_graph_assembly_with_mock_data()))
    except Exception as e:
        print(f"❌ Test failed: {e}")
        results.append(("Graph Assembly", False))
    
    try:
        results.append(("Node Deduplication", test_node_deduplication()))
    except Exception as e:
        print(f"❌ Test failed: {e}")
        results.append(("Node Deduplication", False))
    
    # 결과 요약
    print("\n" + "=" * 80)
    print("TEST SUMMARY")
    print("=" * 80)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} - {test_name}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 All tests passed!")
        sys.exit(0)
    else:
        print("\n⚠️  Some tests failed")
        sys.exit(1)
