"""
파서 레지스트리 시스템 테스트

새로운 CLI 파서 구조를 테스트합니다.
"""

import sys
import os

# 프로젝트 루트를 sys.path에 추가
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.collectors.cli_parsers import parse_cli, get_parser, list_supported_services
from app.collectors.cli_handler import run_cli_collector


def test_registry_loading():
    """파서 레지스트리가 올바르게 로드되는지 테스트"""
    print("=" * 80)
    print("TEST 1: Parser Registry Loading")
    print("=" * 80)
    
    services = list_supported_services()
    print(f"\n✅ Loaded services: {services}")
    
    assert "iam" in services, "IAM parser should be loaded"
    print("✅ IAM parser registered")
    
    return True


def test_iam_create_user():
    """IAM create-user 명령어 파싱 테스트"""
    print("\n" + "=" * 80)
    print("TEST 2: IAM create-user")
    print("=" * 80)
    
    cli = "aws iam create-user --user-name developer"
    result = parse_cli(cli, "123456789012")
    
    print(f"\n✅ Parsed CLI: {cli}")
    print(f"   Nodes: {len(result['nodes'])}")
    print(f"   Node type: {result['nodes'][0]['node_type']}")
    print(f"   Name: {result['nodes'][0]['name']}")
    
    assert len(result["nodes"]) == 1
    assert result["nodes"][0]["node_type"] == "iam_user"
    assert result["nodes"][0]["name"] == "developer"
    
    print("✅ create-user parsing works!")
    return True


def test_iam_put_user_policy():
    """IAM put-user-policy 명령어 파싱 테스트 (기존 로직)"""
    print("\n" + "=" * 80)
    print("TEST 3: IAM put-user-policy (Backward Compatibility)")
    print("=" * 80)
    
    cli = """aws iam put-user-policy --user-name admin --policy-name S3Access --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["s3:GetObject","s3:ListBucket"],"Resource":"*"}]}'"""
    
    result = parse_cli(cli, "123456789012")
    
    print(f"\n✅ Parsed put-user-policy")
    print(f"   User: {result['nodes'][0]['name']}")
    print(f"   Policies: {len(result['nodes'][0]['attributes']['inline_policies'])}")
    
    policy = result['nodes'][0]['attributes']['inline_policies'][0]
    print(f"   Policy Name: {policy['PolicyName']}")
    print(f"   Statements: {len(policy['Statement'])}")
    
    assert result['nodes'][0]['name'] == "admin"
    assert len(result['nodes'][0]['attributes']['inline_policies']) == 1
    assert policy['PolicyName'] == "S3Access"
    
    print("✅ put-user-policy parsing works!")
    return True


def test_iam_attach_user_policy():
    """IAM attach-user-policy 명령어 파싱 테스트"""
    print("\n" + "=" * 80)
    print("TEST 4: IAM attach-user-policy")
    print("=" * 80)
    
    cli = "aws iam attach-user-policy --user-name dev --policy-arn arn:aws:iam::aws:policy/ReadOnlyAccess"
    result = parse_cli(cli, "123456789012")
    
    print(f"\n✅ Parsed attach-user-policy")
    print(f"   User: {result['nodes'][0]['name']}")
    
    attached = result['nodes'][0]['attributes']['attached_policies']
    print(f"   Attached Policies: {len(attached)}")
    print(f"   Policy Name: {attached[0]['PolicyName']}")
    print(f"   Policy ARN: {attached[0]['PolicyArn']}")
    
    assert result['nodes'][0]['name'] == "dev"
    assert len(attached) == 1
    assert attached[0]['PolicyName'] == "ReadOnlyAccess"
    
    print("✅ attach-user-policy parsing works!")
    return True


def test_iam_create_role():
    """IAM create-role 명령어 파싱 테스트"""
    print("\n" + "=" * 80)
    print("TEST 5: IAM create-role")
    print("=" * 80)
    
    cli = """aws iam create-role --role-name LambdaRole --assume-role-policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"lambda.amazonaws.com"},"Action":"sts:AssumeRole"}]}'"""
    
    result = parse_cli(cli, "123456789012")
    
    print(f"\n✅ Parsed create-role")
    print(f"   Role: {result['nodes'][0]['name']}")
    print(f"   Node type: {result['nodes'][0]['node_type']}")
    
    trust_policy = result['nodes'][0]['attributes']['assume_role_policy']
    print(f"   Trust Policy Version: {trust_policy.get('Version')}")
    
    assert result['nodes'][0]['node_type'] == "iam_role"
    assert result['nodes'][0]['name'] == "LambdaRole"
    assert 'assume_role_policy' in result['nodes'][0]['attributes']
    
    print("✅ create-role parsing works!")
    return True


def test_iam_create_group():
    """IAM create-group 명령어 파싱 테스트"""
    print("\n" + "=" * 80)
    print("TEST 6: IAM create-group")
    print("=" * 80)
    
    cli = "aws iam create-group --group-name developers"
    result = parse_cli(cli, "123456789012")
    
    print(f"\n✅ Parsed create-group")
    print(f"   Group: {result['nodes'][0]['name']}")
    print(f"   Node type: {result['nodes'][0]['node_type']}")
    
    assert result['nodes'][0]['node_type'] == "iam_group"
    assert result['nodes'][0]['name'] == "developers"
    
    print("✅ create-group parsing works!")
    return True


def test_cli_handler_integration():
    """cli_handler 통합 테스트"""
    print("\n" + "=" * 80)
    print("TEST 7: cli_handler Integration")
    print("=" * 80)
    
    cli = "aws iam create-user --user-name test-user"
    result = run_cli_collector(cli, "123456789012")
    
    print(f"\n✅ cli_handler integration works")
    print(f"   Result keys: {result.keys()}")
    print(f"   Nodes: {len(result.get('nodes', []))}")
    
    assert 'nodes' in result
    assert len(result['nodes']) == 1
    
    print("✅ cli_handler works with new parser!")
    return True


def test_legacy_compatibility():
    """레거시 함수 호환성 테스트"""
    print("\n" + "=" * 80)
    print("TEST 8: Legacy Compatibility (CliToNode)")
    print("=" * 80)
    
    from app.collectors.CliToNode import cli_put_user_policy_to_iam_user_json
    
    cli = "aws iam create-user --user-name legacy-test"
    result = cli_put_user_policy_to_iam_user_json(cli, "123456789012")
    
    print(f"\n✅ Legacy function still works")
    print(f"   User: {result['nodes'][0]['name']}")
    
    assert result['nodes'][0]['name'] == "legacy-test"
    
    print("✅ Backward compatibility maintained!")
    return True


def test_auto_service_detection():
    """자동 서비스 감지 테스트"""
    print("\n" + "=" * 80)
    print("TEST 9: Auto Service Detection")
    print("=" * 80)
    
    # IAM 명령어
    iam_cli = "aws iam create-user --user-name test"
    iam_result = parse_cli(iam_cli, "123456789012")
    
    print(f"\n✅ Auto-detected IAM service")
    print(f"   Command: {iam_cli[:50]}...")
    print(f"   Node type: {iam_result['nodes'][0]['node_type']}")
    
    assert iam_result['nodes'][0]['node_type'] == "iam_user"
    
    print("✅ Service auto-detection works!")
    return True


if __name__ == "__main__":
    print("\n🧪 Starting Parser Registry Tests\n")
    
    results = []
    
    try:
        results.append(("Registry Loading", test_registry_loading()))
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        results.append(("Registry Loading", False))
    
    try:
        results.append(("create-user", test_iam_create_user()))
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        results.append(("create-user", False))
    
    try:
        results.append(("put-user-policy", test_iam_put_user_policy()))
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        results.append(("put-user-policy", False))
    
    try:
        results.append(("attach-user-policy", test_iam_attach_user_policy()))
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        results.append(("attach-user-policy", False))
    
    try:
        results.append(("create-role", test_iam_create_role()))
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        results.append(("create-role", False))
    
    try:
        results.append(("create-group", test_iam_create_group()))
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        results.append(("create-group", False))
    
    try:
        results.append(("cli_handler Integration", test_cli_handler_integration()))
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        results.append(("cli_handler Integration", False))
    
    try:
        results.append(("Legacy Compatibility", test_legacy_compatibility()))
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        results.append(("Legacy Compatibility", False))
    
    try:
        results.append(("Auto Service Detection", test_auto_service_detection()))
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        results.append(("Auto Service Detection", False))
    
    # 결과 요약
    print("\n" + "=" * 80)
    print("TEST SUMMARY")
    print("=" * 80)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} - {test_name}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 All tests passed!")
        print("\n✨ Parser Registry System is working perfectly!")
        print("\nReady for:")
        print("  - process_simulation integration")
        print("  - EC2/S3 parser additions")
        print("  - Production deployment")
        sys.exit(0)
    else:
        print("\n⚠️  Some tests failed")
        sys.exit(1)
