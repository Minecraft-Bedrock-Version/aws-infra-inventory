"""
사용 예제: process_simulation 함수

이 파일은 process_simulation 함수를 실제로 어떻게 사용하는지 보여주는 예제입니다.
"""

import json
from app.handler.lambda_handler import process_simulation


def example_1_basic_usage():
    """예제 1: 기본 사용법"""
    print("=" * 80)
    print("예제 1: IAM User에 S3 권한 추가")
    print("=" * 80)
    
    # AWS CLI 명령어 문자열
    cli_script = """
    aws iam put-user-policy \
      --user-name developer \
      --policy-name S3AccessPolicy \
      --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["s3:GetObject","s3:PutObject","s3:ListBucket"],"Resource":"*"}]}'
    """
    
    # 시뮬레이션 실행
    result = process_simulation(
        cli_script=cli_script,
        account_id="288528695623",  # 실제 계정 ID로 변경
        region="us-east-1"
    )
    
    # 결과 출력
    print(f"\n✅ 시뮬레이션 완료!")
    print(f"총 노드: {len(result['nodes'])}")
    print(f"총 엣지: {len(result['edges'])}")
    print(f"제안된 노드: {result['metadata']['proposed_nodes']}")
    
    return result


def example_2_multiple_commands():
    """예제 2: 여러 CLI 명령어"""
    print("\n" + "=" * 80)
    print("예제 2: IAM User 생성 + 정책 추가 (향후 지원)")
    print("=" * 80)
    
    # 현재는 put-user-policy만 지원
    # 향후 create-user, attach-user-policy 등도 추가 가능
    
    cli_script = """
    aws iam put-user-policy \
      --user-name test-user \
      --policy-name AdminPolicy \
      --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":"*","Resource":"*"}]}'
    """
    
    result = process_simulation(
        cli_script=cli_script,
        account_id="123456789012",
        region="us-east-1"
    )
    
    print(f"\n✅ 시뮬레이션 완료!")
    
    return result


def example_3_analyze_results():
    """예제 3: 결과 분석"""
    print("\n" + "=" * 80)
    print("예제 3: 결과 분석 및 시각화 준비")
    print("=" * 80)
    
    cli_script = """
    aws iam put-user-policy \
      --user-name scp-test \
      --policy-name AllowAssumeRole \
      --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":"sts:AssumeRole","Resource":"*"}]}'
    """
    
    result = process_simulation(
        cli_script=cli_script,
        account_id="288528695623",
        region="us-east-1"
    )
    
    # 제안된 노드들만 필터링
    proposed_nodes = [
        node for node in result['nodes']
        if node.get('properties', {}).get('status') == 'proposed'
    ]
    
    print(f"\n📊 분석 결과:")
    print(f"  전체 노드: {len(result['nodes'])}")
    print(f"  - 실제 인프라: {result['metadata']['actual_nodes']}")
    print(f"  - 제안된 변경: {result['metadata']['proposed_nodes']}")
    
    print(f"\n📍 제안된 노드 상세:")
    for node in proposed_nodes:
        print(f"  • {node['type']}: {node['name']}")
        print(f"    - ID: {node['id']}")
        print(f"    - 상태: {node['properties']['status']}")
        
        # 정책 정보 출력
        inline_policies = node.get('properties', {}).get('inline_policies', [])
        if inline_policies:
            print(f"    - 인라인 정책: {len(inline_policies)}개")
            for policy in inline_policies:
                print(f"      • {policy.get('PolicyName')}")
    
    # 연결된 엣지 확인
    proposed_node_ids = {node['id'] for node in proposed_nodes}
    connected_edges = [
        edge for edge in result['edges']
        if edge['src'] in proposed_node_ids or edge['dst'] in proposed_node_ids
    ]
    
    print(f"\n🔗 제안된 노드와 연결된 엣지: {len(connected_edges)}개")
    for edge in connected_edges[:5]:  # 처음 5개만
        print(f"  • {edge['relation']}: {edge['src']} → {edge['dst']}")
    
    # 결과를 파일로 저장 (프론트엔드 전송용)
    output_file = "simulation_for_frontend.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    print(f"\n💾 결과 저장됨: {output_file}")
    print("   → 이 파일을 프론트엔드 그래프 시각화에 사용하세요!")
    
    return result


def example_4_integration_with_lambda():
    """예제 4: Lambda 핸들러 통합"""
    print("\n" + "=" * 80)
    print("예제 4: Lambda 핸들러와 통합 (참고용)")
    print("=" * 80)
    
    print("""
    기존 lambda_handler를 process_simulation으로 대체하려면:
    
    def lambda_handler(event, context):
        cli_script = event.get('cli_input', '')
        account_id = event.get('account_id', '123456789012')
        region = event.get('region', 'us-east-1')
        
        # process_simulation 호출
        result = process_simulation(cli_script, account_id, region)
        
        return {
            'statusCode': 200,
            'body': json.dumps(result, ensure_ascii=False)
        }
    
    또는 기존 로직을 유지하면서 옵션으로 제공:
    
    def lambda_handler(event, context):
        use_simulation = event.get('use_simulation', False)
        
        if use_simulation:
            return process_simulation(...)
        else:
            # 기존 로직
            ...
    """)


if __name__ == "__main__":
    print("\n🚀 process_simulation 사용 예제 실행\n")
    
    # 예제 1 실행
    result1 = example_1_basic_usage()
    
    # 예제 2 실행
    result2 = example_2_multiple_commands()
    
    # 예제 3 실행 (가장 상세한 예제)
    result3 = example_3_analyze_results()
    
    # 예제 4는 설명만 출력
    example_4_integration_with_lambda()
    
    print("\n" + "=" * 80)
    print("✅ 모든 예제 실행 완료!")
    print("=" * 80)
