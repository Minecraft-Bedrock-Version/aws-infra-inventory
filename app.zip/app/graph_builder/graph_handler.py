import re
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
import json

# 1. 개별 리소스 빌더 임포트
from app.graph_builder.iam_user_graph import transform_iam_users
from app.graph_builder.iam_role_graph import transform_iam_roles
from app.graph_builder.igw_graph import transform_igw_to_graph
from app.graph_builder.ec2_graph import transform_ec2_to_graph
from app.graph_builder.rds_graph import transform_rds_to_graph
from app.graph_builder.route_table_graph import transform_route_table_to_graph
from app.graph_builder.subnet_graph import transform_subnet_to_graph
from app.graph_builder.vpc_graph import transform_vpc_to_graph
from app.graph_builder.lambda_graph import transform_lambda_to_graph
from app.graph_builder.sqs_graph import transform_sqs_to_graph

def safe_node(n):
    if not n: return None
    if isinstance(n, dict): return n
    try:
        curr = n
        for _ in range(3):
            if isinstance(curr, (str, bytes)):
                curr = json.loads(curr)
            else:
                break
        return curr if isinstance(curr, dict) else None
    except:
        return None

class GraphAssembler:
    def __init__(self):
        self.transformer_map = {
            "iam_user": transform_iam_users,
            "iam_role": transform_iam_roles,
            "igw": transform_igw_to_graph,
            "ec2": transform_ec2_to_graph,
            "rds": transform_rds_to_graph,
            "route_table": transform_route_table_to_graph,
            "sqs": transform_sqs_to_graph,
            "lambda": transform_lambda_to_graph,
            "subnet": transform_subnet_to_graph,
            "vpc": transform_vpc_to_graph
        }

    def assemble(self, normalized_data_map: Dict[str, Any], cli_graph: Dict[str, Any] = None) -> Dict[str, Any]:
        master_nodes = {}
        master_edges = {}
        account_id = str(normalized_data_map.get("account_id", "288528695623"))

        # 1. 인프라 데이터 수집 및 ID 강제 변환
        for key, data in normalized_data_map.items():
            if key in ["account_id", "region", "collected_at", "schema_version"]:
                continue
            
            current_data = safe_node(data)
            if not isinstance(current_data, dict) or "nodes" not in current_data:
                continue

            # 트랜스포머 실행
            func = self.transformer_map.get(key) or self.transformer_map.get(key.rstrip('s'))
            if func:
                try:
                    res_graph = func(current_data)
                    for n in res_graph.get("nodes", []):
                        # [핵심] 여기서 이름을 체크하여 ID를 CLI와 일치시킴
                        if n.get("name") == "scp-test":
                            n["id"] = f"iam_user:{account_id}:scp-test"
                        
                        n_id = n.get("id")
                        if n_id:
                            master_nodes[n_id] = n
                    
                    for e in res_graph.get("edges", []):
                        if e.get("id"): master_edges[e["id"]] = e
                except Exception:
                    continue

        # 2. CLI 그래프 병합 (이제 ID가 같으므로 scp-test 노드에 정책이 합쳐짐)
        if cli_graph and cli_graph.get("nodes"):
            for cli_node in cli_graph["nodes"]:
                # CLI 노드의 ID는 이미 iam_user:288528695623:scp-test 형식임
                c_id = cli_node.get("node_id")
                
                if c_id in master_nodes:
                    # 인프라 노드에 CLI에서 온 정책 정보를 덮어씌움
                    master_nodes[c_id].setdefault("attributes", {}).update(cli_node.get("attributes", {}))
                else:
                    # 만약 인프라에 없었다면 새로 추가 (안전장치)
                    master_nodes[c_id] = self._convert_to_node_schema(cli_node, account_id)

                # 엣지 생성 (관계 확장)
                new_edges = self._create_edges_and_placeholders(cli_node, master_nodes, account_id)
                for e in new_edges:
                    master_edges[e["id"]] = e
        return {
            "nodes": list(master_nodes.values()),
            "edges": list(master_edges.values()),
            "account_id": account_id,
            "collected_at": datetime.now().isoformat()
        }
        
    def _convert_to_node_schema(self, node: Dict[str, Any], account_id: str) -> Dict[str, Any]:
        """정규화 포맷 노드를 최종 Node Schema로 변환"""
        node_id = node.get("node_id") or node.get("id")
        # node_id에서 region 추출 (형식: account:region:type:id)
        parts = node_id.split(":")
        region = parts[1] if len(parts) > 1 else "global"

        return {
            "id": node_id,
            "type": node.get("node_type") or node.get("type"),
            "name": node.get("name", "Unknown"),
            "arn": node.get("attributes", {}).get("arn", ""),
            "region": region,
            "properties": {
                **node.get("attributes", {}),
                "source": node.get("raw_refs", {}).get("source", [])
            }
        }

    def _create_edges_and_placeholders(self, cli_node: Dict[str, Any], master_nodes: Dict[str, Any], account_id: str) -> List[Dict[str, Any]]:
        generated_edges = []
        src_id = cli_node.get("node_id")
        src_label = f"{cli_node.get('node_type')}:{cli_node.get('name')}"
        
        # 리소스 타입별 매칭 가능한 서비스 접두사 정의
        service_map = {
            "rds_instance": "rds",
            "rds": "rds",
            "sqs": "sqs",
            "lambda_function": "lambda",
            "lambda": "lambda",
            "ec2_instance": "ec2",
            "ec2": "ec2",
            "iam_role": "iam",
            "iam_user": "iam"
        }

        inline_policies = cli_node.get("attributes", {}).get("inline_policies", [])
        for policy in inline_policies:
            for stmt in policy.get("Statement", []):
                resource_arn = stmt.get("Resource")
                actions = stmt.get("Action", [])
                if isinstance(actions, str): actions = [actions]
                
                if not resource_arn: continue

                # [핵심] Resource가 "*" 인 경우 Action 분석 후 매칭
                if resource_arn == "*":
                    for target_id, target_node in master_nodes.items():
                        if target_id == src_id: continue
                        
                        target_type = target_node.get("type", "").lower()
                        service_prefix = service_map.get(target_type)
                        
                        if not service_prefix: continue
                        
                        # Action 중 해당 서비스와 매칭되는 것이 있는지 확인 (예: rds:* 또는 iam:Get*)
                        is_match = any(
                            act == "*" or 
                            act.startswith(f"{service_prefix}:") or 
                            act == f"{service_prefix}:*"
                            for act in actions
                        )
                        
                        if is_match:
                            edge_id = f"edge:{src_id}:ActionMatch:{target_id}"
                            generated_edges.append({
                                "id": edge_id,
                                "relation": "AllowAccess",
                                "src": src_id,
                                "src_label": src_label,
                                "dst": target_id,
                                "dst_label": f"{target_node.get('type')}:{target_node.get('name')}",
                                "directed": True,
                                "conditions": actions # 허용된 전체 액션을 조건으로 기입
                            })
                    continue

                arns = resource_arn if isinstance(resource_arn, list) else [resource_arn]
                for arn in arns:
                    # 1. 기존 노드 중 ARN 매칭 확인
                    dst_node = next((n for n in master_nodes.values() if n.get("arn") == arn), None)
                    
                    # 2. 없으면 가상 노드(Placeholder) 생성
                    if not dst_node:
                        dst_node = self._create_placeholder_node(arn, account_id)
                        master_nodes[dst_node["id"]] = dst_node

                    # 3. 엣지 생성
                    relation = f"{stmt.get('Effect', 'Allow')}Access"
                    edge_id = f"edge:{src_id}:{relation}:{dst_node['id']}"
                    
                    generated_edges.append({
                        "id": edge_id,
                        "relation": relation,
                        "src": src_id,
                        "src_label": src_label,
                        "dst": dst_node["id"],
                        "dst_label": f"{dst_node['type']}:{dst_node['name']}",
                        "directed": True,
                        "conditions": stmt.get("Action", [])
                    })
        return generated_edges

    def _create_placeholder_node(self, arn: str, account_id: str) -> Dict[str, Any]:
        """ARN을 분석하여 존재하지 않는 리소스를 위한 가상 노드 생성"""
        # ARN 파싱 (arn:aws:service:region:account:resource)
        parts = arn.split(":")
        service = parts[2] if len(parts) > 2 else "unknown"
        region = parts[3] if len(parts) > 3 and parts[3] else "global"
        
        # 이름 추출 (마지막 섹션의 / 이후)
        res_name = parts[-1].split("/")[-1] if parts else "Unknown-Resource"
        
        # 우리 팀의 ID 규칙 적용
        virtual_id = f"{account_id}:{region}:{service}:{res_name}"
        
        return {
            "id": virtual_id,
            "type": service,
            "name": res_name,
            "arn": arn,
            "region": region,
            "properties": {
                "status": "placeholder",
                "exists_in_infra": False,
                "reason": "Created from CLI policy reference"
            }
        }

    # --- 기존 Merge 헬퍼 함수들 (유지) ---
    def _merge_graph_to_master(self, master_nodes, master_edges, sub_graph):
        for n in sub_graph.get("nodes", []):
            n_id = n.get("id")
            master_nodes[n_id] = self._merge_nodes(master_nodes.get(n_id, {}), n)
        for e in sub_graph.get("edges", []):
            e_id = e.get("id")
            master_edges[e_id] = self._merge_edges(master_edges.get(e_id, {}), e)

    def _merge_nodes(self, old: Dict[str, Any], new: Dict[str, Any]) -> Dict[str, Any]:
        merged = dict(old)
        for key in ["type", "name", "arn", "region"]:
            if not merged.get(key) and new.get(key):
                merged[key] = new[key]
        old_props = old.get("properties", {})
        new_props = new.get("properties", {})
        merged_props = {**old_props}
        for k, v in new_props.items():
            if k not in merged_props:
                merged_props[k] = v
            else:
                merged_props[k] = self._merge_property_value(merged_props[k], v)
        merged["properties"] = merged_props
        return merged

    def _merge_property_value(self, old_value: Any, new_value: Any) -> Any:
        if isinstance(old_value, dict) and isinstance(new_value, dict):
            merged = dict(old_value)
            for k, v in new_value.items():
                merged[k] = self._merge_property_value(merged.get(k), v) if k in merged else v
            return merged
        if isinstance(old_value, list) and isinstance(new_value, list):
            return list(set(map(str, old_value)) | set(map(str, new_value)))
        return new_value

    def _merge_edges(self, old: Dict[str, Any], new: Dict[str, Any]) -> Dict[str, Any]:
        merged = {**old, **new}
        return merged