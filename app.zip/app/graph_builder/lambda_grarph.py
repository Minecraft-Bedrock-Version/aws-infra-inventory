from typing import Any, Dict, List

def transform_lambda_to_graph(normalized_data: Dict[str, Any]) -> Dict[str, Any]:

    graph_data = {
        "schema_version": "1.0",
        "collected_at": normalized_data.get("collected_at"),
        "account_id": normalized_data.get("account_id"),
        "nodes": [],
        "edges": []
    }

    account_id = normalized_data.get("account_id")

    for node in normalized_data.get("nodes", []):
        node_type = node.get("node_type")
        n_id = node.get("node_id")
        res_id = node.get("resource_id")
        region = node.get("region")
        attrs = node.get("attributes", {})
        name = node.get("name")
        
        # 1-1. Lambda Function 노드
        if node_type == "lambda_function":
            new_node = {
                "id": n_id,
                "type": "lambda_function",
                "name": name,
                "arn": attrs.get("arn") or f"arn:aws:lambda:{region}:{account_id}:function:{name}",
                "region": region,
                "properties": {
                    "runtime": attrs.get("runtime"),
                    "handler": attrs.get("handler"),
                    "timeout": attrs.get("timeout"),
                    "memory_size": attrs.get("memory_size"),
                    "env_vars": attrs.get("env_vars", {}),
                    "ephemeral_storage": attrs.get("ephemeral_storage"),
                    "vpc_config": attrs.get("vpc_config", {}),
                    "last_modified": attrs.get("last_modified")
                }
            }
            graph_data["nodes"].append(new_node)

            # 2-1. ASSUME_ROLE 엣지 (Lambda -> IAM Role)
            role_name = attrs.get("role_name") # 정규화 데이터에 role_name이 있다고 가정
            if role_name:
                graph_data["edges"].append({
                    "id": f"edge:{name}:ASSUME_ROLE:{role_name}",
                    "relation": "ASSUME_ROLE",
                    "src": n_id,
                    "src_label": f"lambda_function:{name}",
                    "dst": f"{account_id}:iam:role:{role_name}",
                    "dst_label": f"iam_role:{role_name}",
                    "directed": True,
                    "conditions": ["sts:AssumeRole"]
                })

            # 2-2. MEMBER_OF 엣지 (Lambda -> VPC)
            vpc_id = attrs.get("vpc_config", {}).get("vpc_id")
            if vpc_id:
                graph_data["edges"].append({
                    "id": f"edge:{name}:MEMBER_OF:{vpc_id}",
                    "relation": "MEMBER_OF",
                    "src": n_id,
                    "src_label": f"lambda_function:{name}",
                    "dst": f"{account_id}:{region}:vpc:{vpc_id}",
                    "dst_label": f"vpc:{vpc_id}",
                    "directed": True,
                    "conditions": ["ec2:CreateNetworkInterface"]
                })

        # 1-2. Lambda Event Source Mapping 노드
        elif node_type == "lambda_event_source_mapping":
            mapping_uuid = res_id # 보통 UUID가 들어옴
            new_node = {
                "id": n_id,
                "type": "lambda_event_source_mapping",
                "name": name,
                "arn": attrs.get("arn"),
                "region": region,
                "properties": {
                    "state": attrs.get("state"),
                    "batch_size": attrs.get("batch_size"),
                    "last_modified": attrs.get("last_modified")
                }
            }
            graph_data["nodes"].append(new_node)

            # 2-3. INVOKES 엣지 (Mapping -> Lambda Function)
            function_name = attrs.get("function_name") # 매핑 데이터가 가리키는 함수명
            if function_name:
                graph_data["edges"].append({
                    "id": f"edge:{mapping_uuid}:INVOKES:{function_name}",
                    "relation": "INVOKES",
                    "src": n_id,
                    "src_label": f"lambda_event_source_mapping:{name}",
                    "dst": f"{account_id}:{region}:lambda_function:{function_name}",
                    "dst_label": f"lambda_function:{function_name}",
                    "directed": True,
                    "conditions": ["lambda:InvokeFunction"]
                })

    return graph_data