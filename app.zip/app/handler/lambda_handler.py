import sys
import os
import json 
from datetime import datetime

from app.collectors.collector_handler import handler as run_collectors
from app.collectors.cli_handler import run_cli_collector
from app.normalizers.normalizer_handler import run_normalizers
from app.graph_builder.graph_handler import GraphAssembler
from app.filters.filter_handler import run_filters 
from app.filters.filterling_handler import run_filtering 

def lambda_handler(event, context):
    print("=== LAMBDA START ===")
    print("EVENT:", json.dumps(event, indent=2, ensure_ascii=False))
    cli_input = event.get("cli_input", "")
    account_id = event.get("account_id", "123456789012")

    # 데이터 수집 및 정규화
    cli_graph = run_cli_collector(cli_input, account_id)
    raw_data = run_collectors(event, context)
    print("RAW_DATA KEYS:", raw_data.keys())
    print("RAW_DATA TYPE:", type(raw_data))
    normalized_data = run_normalizers(raw_data)
    print("NORMALIZED KEYS:", normalized_data.keys())
    
    print("==== TYPE CHECK AFTER NORMALIZE ====")
    for k, v in normalized_data.items():
        print(f"{k}: {type(v)}")
        if isinstance(v, str):
            print(f"[WARN] {k} is STRING, value preview: {v[:200]}")
    
    resource_map = {}
    for k, v in normalized_data.items():
        target_v = v
        if isinstance(v, str):
            try:
                target_v = json.loads(v)
            except: continue
        
        if isinstance(target_v, dict) and "nodes" in target_v:
            resource_map[k] = target_v

    # 그래프 조립 및 연결
    assembler = GraphAssembler()
    print("ASSEMBLER INPUT KEYS:", resource_map.keys())
    for k, v in resource_map.items():
        print(k, "TYPE:", type(v), "nodes:", len(v["nodes"]))

    # assembler 내부에서 이미 id, properties 포맷으로 통일됨
    resource_map["account_id"] = account_id 
    full_graph = assembler.assemble(resource_map, cli_graph)
    
    # n['id'] 대신 n.get('id') 사용 및 None 필터링
    all_node_ids = [n.get('id') for n in full_graph.get('nodes', []) if n.get('id')]
    
    print(f"DEBUG: Full Graph Node IDs: {all_node_ids[:10]}... (Total: {len(all_node_ids)})")

    full_graph["account_id"] = account_id # 메타데이터 주입
    print("FULL_GRAPH:", {
        "nodes": len(full_graph.get("nodes", [])),
        "edges": len(full_graph.get("edges", []))
    })
    print("CLI_GRAPH:", cli_graph)
    # 필터링 및 필드 정제 
    if cli_graph.get("nodes"):
        start_id = cli_graph["nodes"][0].get("node_id")
        print(f"DEBUG: Searching for START_ID: {start_id}")
        
        # 필터링
        sub_graph = run_filters(full_graph, start_id)
        print(f"DEBUG: Sub-graph result - Nodes: {len(sub_graph.get('nodes', []))}")

        # 2. 최종 정제 (데이터가 있을 때만 실행)
        if sub_graph.get("nodes"):
            final_ai_graph = run_filtering(sub_graph, start_id)
            print(f"CHECK: final_ai_graph nodes count = {len(final_ai_graph.get('nodes', []))}")
            print(f"CHECK: final_ai_graph content = {json.dumps(final_ai_graph)[:500]}")
        else:
            print("WARN: No nodes found in sub_graph. Returning full_graph instead.")
            final_ai_graph = full_graph
    else:
        final_ai_graph = {
            "schema_version": "1.0",
            "collected_at": datetime.now().isoformat(),
            "account_id": account_id,
            "nodes": [],
            "edges": []
        }
   
    # 지정 경로에 파일 저장
    # target_path = os.path.expanduser("~/ai_web-ui/backend/json/pandyo/search_pandyo.json")
    
    # try:
    #     os.makedirs(os.path.dirname(target_path), exist_ok=True)
    #     with open(target_path, "w", encoding="utf-8") as f:
    #         json.dump(final_ai_graph, f, ensure_ascii=False, indent=2)
    #     save_status = f"Success: File overwritten at {target_path}"
    # except Exception as e:
    #     save_status = f"Fail: {str(e)}"
        
    return {
        "statusCode": 200,
        "body": json.dumps(final_ai_graph)
    }