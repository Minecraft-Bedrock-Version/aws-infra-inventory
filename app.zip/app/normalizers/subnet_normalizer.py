from datetime import datetime, timezone

def normalize_subnets(collected, account_id, region):
    nodes = []
    
    subnet_to_rt = {}
    for rt_item in collected:
        rt = rt_item["route_table"]
        rt_id = rt["RouteTableId"]
        for assoc in rt.get("Associations", []):
            if "SubnetId" in assoc:
                subnet_to_rt[assoc["SubnetId"]] = rt_id

    for item in collected:
        sn = item["subnet"]
        sn_id = sn["SubnetId"]
        
        sn_name = None
        for tag in sn.get("Tags", []):
            if tag["Key"] == "Name":
                sn_name = tag["Value"]

        node = {
            "node_type": "subnet",
            "node_id": f"{account_id}:{region}:subnet:{sn_id}",
            "resource_id": sn_id,
            "name": sn_name,
            "attributes": {
                "vpc_id": sn.get("VpcId"),
                "cidr": sn.get("CidrBlock"),
                "az": sn.get("AvailabilityZone"),
                "visibility": "unknown", 
                "route_table_id": subnet_to_rt.get(sn_id)
            },
            "raw_refs": {
                "source": item.get("api_sources", ["ec2:DescribeSubnets"]),
                "collected_at": item.get("collected_at")
            }
        }
        nodes.append(node)

    return nodes